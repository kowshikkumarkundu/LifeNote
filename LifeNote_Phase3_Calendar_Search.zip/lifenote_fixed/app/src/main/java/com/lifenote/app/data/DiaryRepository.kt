package com.lifenote.app.data

import com.lifenote.app.data.local.DiaryEntry
import com.lifenote.app.data.local.DiaryEntryDao
import kotlinx.coroutines.flow.Flow

class DiaryRepository(private val dao: DiaryEntryDao) {
    val entries: Flow<List<DiaryEntry>> = dao.observeAll()
    suspend fun save(entry: DiaryEntry): Long = dao.insert(entry)
    suspend fun find(id: Long): DiaryEntry? = dao.getById(id)
    suspend fun delete(entry: DiaryEntry) = dao.delete(entry)
}
