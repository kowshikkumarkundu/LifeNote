package com.lifenote.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

/** Small foundation table; feature-specific tables are introduced in their planned phases. */
@Entity(tableName = "app_metadata")
data class AppMetadataEntity(
    @PrimaryKey val key: String,
    val value: String
)
