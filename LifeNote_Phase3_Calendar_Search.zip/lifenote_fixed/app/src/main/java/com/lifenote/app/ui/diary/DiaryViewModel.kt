package com.lifenote.app.ui.diary

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.lifenote.app.data.DiaryRepository
import com.lifenote.app.data.local.AppDatabase
import com.lifenote.app.data.local.DiaryEntry
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch

class DiaryViewModel(application: Application) : AndroidViewModel(application) {
    private val repository = DiaryRepository(AppDatabase.getInstance(application).diaryEntryDao())
    val entries = repository.entries.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5_000), emptyList())

    fun save(entry: DiaryEntry, onSaved: (Long) -> Unit = {}) {
        viewModelScope.launch {
            val now = System.currentTimeMillis()
            val id = repository.save(entry.copy(updatedAt = now))
            onSaved(if (entry.id == 0L) id else entry.id)
        }
    }

    fun delete(entry: DiaryEntry) { viewModelScope.launch { repository.delete(entry) } }
}
