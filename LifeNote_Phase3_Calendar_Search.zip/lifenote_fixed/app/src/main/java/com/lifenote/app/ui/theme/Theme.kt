package com.lifenote.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val LifeNoteLightColors = lightColorScheme(
    primary = Color(0xFF52665A),
    onPrimary = Color.White,
    secondary = Color(0xFF8A7561),
    background = Color(0xFFFAF8F3),
    surface = Color(0xFFFFFEFB),
    surfaceVariant = Color(0xFFECEAE2)
)

@Composable
fun LifeNoteTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = LifeNoteLightColors, content = content)
}
