package com.lifenote.app.data.preferences

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.map

private val Context.dataStore by preferencesDataStore(name = "lifenote_preferences")

class UserPreferences(private val context: Context) {
    private val languageKey = stringPreferencesKey("app_language")
    private val themeKey = stringPreferencesKey("app_theme")

    val language: Flow<String> = context.dataStore.data.map { it[languageKey] ?: "system" }
    val theme: Flow<String> = context.dataStore.data.map { it[themeKey] ?: "light" }

    suspend fun setLanguage(value: String) { context.dataStore.edit { it[languageKey] = value } }
    suspend fun setTheme(value: String) { context.dataStore.edit { it[themeKey] = value } }
}
