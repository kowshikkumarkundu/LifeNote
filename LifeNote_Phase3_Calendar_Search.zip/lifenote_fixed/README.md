# LifeNote — Phase 3: Calendar & Diary Search

Phase 3 builds on the existing offline diary without changing its stored entries or media paths.

## Included
- Month calendar with previous/next month navigation and a Today shortcut
- Calendar markers on dates that contain diary entries
- Select a date to see all diary entries created on that date
- Open a diary directly from the calendar
- Diary list search by title, diary text, and displayed date / ISO date (yyyy-MM-dd)
- Clear search and an empty-results message
- Existing diary reader/editor, image and voice-note attachments, and image save-to-gallery behavior retained
- No database schema change in this phase; existing diary data is retained
- Offline-first; no login, backend, cloud sync, ads, or analytics

## Build on GitHub Actions
1. Remove the previous project ZIP from the repository root before uploading this one.
2. Upload this ZIP to the repository root.
3. Keep the existing repository workflow file unchanged.
4. Run the **Build LifeNote APK** workflow and download the APK artifact after a successful run.

Build requirements: JDK 17, Gradle 8.13, Android SDK 36.
