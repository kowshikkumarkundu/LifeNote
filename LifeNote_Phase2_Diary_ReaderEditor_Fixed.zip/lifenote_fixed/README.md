# LifeNote — Phase 2: Daily Diary

Phase 2 adds a locally stored diary feature to the Phase 1 Android foundation.

## Included
- Multiple diary entries on the same day
- Optional title and diary text (Bangla and English input supported by Android keyboard)
- Creation date and time
- Create, edit, delete, and chronological diary list
- Debounced automatic saving while writing, plus a Done action
- Attach an image stored in the app's private internal files; tap the image in the editor to preview
- Record a voice note using the microphone and play it back from the editor
- Room database schema version 2 with a 1-to-2 migration; the existing metadata table is retained
- Offline-first; no login, backend, cloud sync, ads, or analytics

## Build on GitHub Actions
1. Upload the contents of this folder to the root of the repository (or upload this ZIP if using the ZIP-extracting workflow).
2. Run the **Build LifeNote APK** workflow.
3. Download the `LifeNote-APK` artifact from the successful Actions run.

Build requirements: JDK 17, Gradle 8.13, Android SDK 36.
