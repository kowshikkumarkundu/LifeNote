package com.lifenote.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.lifenote.app.backup.BackupRestoreScreen
import com.lifenote.app.security.SecurityStore
import com.lifenote.app.security.SecuritySettingsScreen
import com.lifenote.app.security.PinLockScreen
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.lifenote.app.R
import com.lifenote.app.ui.diary.DiaryScreen
import com.lifenote.app.ui.calendar.CalendarScreen
import com.lifenote.app.ui.phase4.Phase4Screen
import com.lifenote.app.ui.todo.ToDoScreen
import com.lifenote.app.ui.phase6.GoalsHabitsScreen
import com.lifenote.app.ui.phase7.Phase7Screen
import androidx.navigation.NavType
import androidx.navigation.navArgument

private data class MainTab(
    val route: String,
    val label: Int,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LifeNoteApp() {
    val context = LocalContext.current
    var locked by remember { mutableStateOf(SecurityStore.hasPin(context)) }
    if (locked) { PinLockScreen(context) { locked = false }; return }
    val navController = rememberNavController()
    var diaryDetailOpen by remember { mutableStateOf(false) }
    val tabs = listOf(
        MainTab("home", R.string.nav_home, Icons.Outlined.Home),
        MainTab("diary", R.string.nav_diary, Icons.Outlined.MenuBook),
        MainTab("calendar", R.string.nav_calendar, Icons.Outlined.CalendarMonth),
        MainTab("todo", R.string.nav_todo, Icons.Outlined.Checklist),
        MainTab("growth", R.string.nav_growth, Icons.Outlined.Flag)
    )
    val backStackEntry = navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry.value?.destination

    Scaffold(
        topBar = { if (!diaryDetailOpen) TopAppBar(title = { Text(stringResource(R.string.app_name)) }) },
        bottomBar = {
            NavigationBar {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true || (tab.route == "home" && currentDestination?.route == "phase4") || (tab.route == "diary" && currentDestination?.route?.startsWith("diaryEntry/") == true),
                        onClick = {
                            diaryDetailOpen = false
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = null) },
                        label = { Text(stringResource(tab.label)) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") { HomeDashboard(onOpenPhase4 = { navController.navigate("phase4") }, onOpenGrowth = { navController.navigate("growth") }, onOpenMore = { navController.navigate("more") }, onOpenSecurity = { navController.navigate("security") }, onOpenBackup = { navController.navigate("backup") }) }
            composable("phase4") { Phase4Screen() }
            composable("diary") { DiaryScreen(onReaderStateChanged = { diaryDetailOpen = it }) }
            composable("diaryEntry/{entryId}", arguments = listOf(navArgument("entryId") { type = NavType.LongType })) { backStack ->
                val entryId = backStack.arguments?.getLong("entryId")
                DiaryScreen(onReaderStateChanged = { diaryDetailOpen = it }, initialEntryId = entryId, onBackFromExternalEntry = { navController.popBackStack() })
            }
            composable("calendar") {
                CalendarScreen(onEntryClick = { id -> navController.navigate("diaryEntry/$id") })
            }
            composable("todo") { ToDoScreen() }
            composable("growth") { GoalsHabitsScreen() }
            composable("more") { Phase7Screen() }
            composable("security") { SecuritySettingsScreen(context) { locked = true } }
            composable("backup") { BackupRestoreScreen(context) }
        }
    }
}

@Composable
private fun PlaceholderScreen(titleRes: Int, showFoundationCard: Boolean = false) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(text = stringResource(titleRes), style = MaterialTheme.typography.headlineSmall)
        }
        if (showFoundationCard) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.phase1_card_title), style = MaterialTheme.typography.titleMedium)
                        Text(stringResource(R.string.phase1_card_body), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            item {
                Text(stringResource(R.string.foundation_note), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun HomeDashboard(onOpenPhase4: () -> Unit, onOpenGrowth: () -> Unit = {}, onOpenMore: () -> Unit = {}, onOpenSecurity: () -> Unit = {}, onOpenBackup: () -> Unit = {}) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item { Text(stringResource(R.string.welcome_title), style = MaterialTheme.typography.headlineSmall) }
        item {
            Card(modifier = Modifier.fillMaxWidth()) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(stringResource(R.string.phase1_card_title), style = MaterialTheme.typography.titleMedium)
                    Text(stringResource(R.string.phase1_card_body), style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), onClick = onOpenPhase4) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("মুড ট্র্যাকার ও বিশেষ স্মৃতি", style = MaterialTheme.typography.titleMedium)
                    Text("প্রতিদিনের অনুভূতি লিখে রাখো এবং জীবনের গুরুত্বপূর্ণ মুহূর্তগুলো ছবি ও বর্ণনাসহ সংরক্ষণ করো।", style = MaterialTheme.typography.bodyMedium)
                    androidx.compose.material3.TextButton(onClick = onOpenPhase4) { Text("শুরু করো") }
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), onClick = onOpenGrowth) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("লক্ষ্য ও অভ্যাস", style = MaterialTheme.typography.titleMedium)
                    Text("জীবনের লক্ষ্য নির্ধারণ করো, অগ্রগতি দেখো এবং প্রতিদিনের অভ্যাস গড়ে তোলো।", style = MaterialTheme.typography.bodyMedium)
                    androidx.compose.material3.TextButton(onClick = onOpenGrowth) { Text("শুরু করো") }
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), onClick = onOpenMore) {
                Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("জীবনের মুহূর্ত ও পরিসংখ্যান", style = MaterialTheme.typography.titleMedium)
                    Text("কৃতজ্ঞতার নোট, ভবিষ্যতের চিঠি, প্রিয় ডায়েরি, On This Day এবং PDF Export।", style = MaterialTheme.typography.bodyMedium)
                    androidx.compose.material3.TextButton(onClick = onOpenMore) { Text("খুলুন") }
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), onClick = onOpenSecurity) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Privacy & Security", style = MaterialTheme.typography.titleMedium)
                    Text("PIN lock চালু, পরিবর্তন বা বন্ধ করো।", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item {
            Card(modifier = Modifier.fillMaxWidth(), onClick = onOpenBackup) {
                Column(Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("Backup & Restore", style = MaterialTheme.typography.titleMedium)
                    Text("তোমার ডায়েরি, ছবি, ভয়েস নোট ও অন্যান্য তথ্যের ব্যাকআপ রাখো এবং প্রয়োজন হলে ফিরিয়ে আনো।", style = MaterialTheme.typography.bodyMedium)
                }
            }
        }
        item { Text("Phase 4 · Mood Tracker · Phase 6 · Goals & Habits · Phase 7 · Reflection · Phase 8 · Security · Phase 9 · Backup", style = MaterialTheme.typography.bodySmall) }
    }
}
