package com.lifenote.app.backup

import android.content.Context
import android.net.Uri
import com.lifenote.app.data.local.AppDatabase
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

object BackupManager {
    private const val DATABASE_NAME = "lifenote.db"

    fun createBackup(context: Context, destination: Uri) {
        val db = AppDatabase.getInstance(context)
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").close()
        context.contentResolver.openOutputStream(destination, "w")?.use { raw ->
            ZipOutputStream(BufferedOutputStream(raw)).use { zip ->
                val database = context.getDatabasePath(DATABASE_NAME)
                require(database.exists()) { "ডেটাবেস পাওয়া যায়নি" }
                addFile(zip, database, DATABASE_NAME)
                addDirectory(zip, File(context.filesDir, ""), context.filesDir, "files/")
            }
        } ?: error("ব্যাকআপ ফাইল তৈরি করা যায়নি")
    }

    fun restoreBackup(context: Context, source: Uri) {
        val tempRoot = File(context.cacheDir, "lifenote_restore_${System.currentTimeMillis()}")
        val tempDb = File(tempRoot, DATABASE_NAME)
        val tempFiles = File(tempRoot, "files")
        tempRoot.mkdirs()
        var databaseFound = false
        try {
            val input = context.contentResolver.openInputStream(source) ?: error("ব্যাকআপ ফাইল খোলা যায়নি")
            ZipInputStream(BufferedInputStream(input)).use { zip ->
                while (true) {
                    val entry = zip.nextEntry ?: break
                    when {
                        entry.name == DATABASE_NAME -> {
                            tempDb.parentFile?.mkdirs()
                            FileOutputStream(tempDb).use { zip.copyTo(it) }
                            databaseFound = true
                        }
                        entry.name.startsWith("files/") && !entry.isDirectory -> {
                            val relative = entry.name.removePrefix("files/")
                            require(relative.isNotBlank() && !relative.startsWith("/") && !relative.split('/').contains("..")) { "ব্যাকআপে অবৈধ ফাইল পাথ আছে" }
                            val out = File(tempFiles, relative)
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { zip.copyTo(it) }
                        }
                    }
                    zip.closeEntry()
                }
            }
            require(databaseFound && tempDb.length() > 100) { "এটি বৈধ LifeNote ব্যাকআপ নয়" }
            FileInputStream(tempDb).use { stream ->
                val header = ByteArray(16)
                require(stream.read(header) == 16 && String(header, Charsets.US_ASCII).startsWith("SQLite format 3")) { "ব্যাকআপ ডেটাবেস সঠিক নয়" }
            }

            AppDatabase.closeForRestore()
            val dbFile = context.getDatabasePath(DATABASE_NAME)
            dbFile.parentFile?.mkdirs()
            File(context.getDatabasePath("${DATABASE_NAME}-wal").path).delete()
            File(context.getDatabasePath("${DATABASE_NAME}-shm").path).delete()
            tempDb.copyTo(dbFile, overwrite = true)

            context.filesDir.listFiles()?.forEach { it.deleteRecursively() }
            if (tempFiles.exists()) copyDirectory(tempFiles, context.filesDir)
        } finally {
            tempRoot.deleteRecursively()
        }
    }

    private fun addDirectory(zip: ZipOutputStream, current: File, root: File, prefix: String) {
        current.listFiles()?.forEach { file ->
            if (file.isDirectory) addDirectory(zip, file, root, prefix)
            else addFile(zip, file, prefix + file.relativeTo(root).invariantSeparatorsPath)
        }
    }

    private fun addFile(zip: ZipOutputStream, file: File, name: String) {
        zip.putNextEntry(ZipEntry(name))
        FileInputStream(file).use { it.copyTo(zip) }
        zip.closeEntry()
    }

    private fun copyDirectory(source: File, destination: File) {
        source.listFiles()?.forEach { file ->
            val target = File(destination, file.name)
            if (file.isDirectory) { target.mkdirs(); copyDirectory(file, target) }
            else file.copyTo(target, overwrite = true)
        }
    }
}
