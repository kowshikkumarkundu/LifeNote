package com.lifenote.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "reminders")
data class ReminderEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val note: String = "",
    val triggerAt: Long,
    val repeatType: String = "NONE",
    val isEnabled: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
