package com.lifenote.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "gratitude_entries")
data class GratitudeEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val body: String,
    val createdAt: Long
)
