package com.lifenote.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface Phase6Dao {
    @Query("SELECT * FROM goals ORDER BY isCompleted ASC, createdAt DESC")
    fun observeGoals(): Flow<List<GoalEntry>>

    @Insert
    suspend fun insertGoal(goal: GoalEntry): Long

    @Update
    suspend fun updateGoal(goal: GoalEntry)

    @Query("DELETE FROM goals WHERE id = :id")
    suspend fun deleteGoal(id: Long)

    @Query("SELECT * FROM habits WHERE isArchived = 0 ORDER BY createdAt DESC")
    fun observeHabits(): Flow<List<HabitEntry>>

    @Insert
    suspend fun insertHabit(habit: HabitEntry): Long

    @Update
    suspend fun updateHabit(habit: HabitEntry)

    @Query("DELETE FROM habits WHERE id = :id")
    suspend fun deleteHabit(id: Long)

    @Query("SELECT * FROM habit_logs WHERE dateKey = :dateKey")
    fun observeLogsForDate(dateKey: String): Flow<List<HabitLogEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveHabitLog(log: HabitLogEntry)

    @Query("SELECT COUNT(*) FROM habit_logs WHERE habitId = :habitId AND isCompleted = 1")
    suspend fun countCompletedDays(habitId: Long): Int
}
