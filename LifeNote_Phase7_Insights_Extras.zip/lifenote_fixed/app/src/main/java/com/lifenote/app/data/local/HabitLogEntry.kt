package com.lifenote.app.data.local

import androidx.room.Entity
import androidx.room.Index

@Entity(tableName = "habit_logs", primaryKeys = ["habitId", "dateKey"], indices = [Index(value = ["dateKey"])])
data class HabitLogEntry(
    val habitId: Long,
    val dateKey: String,
    val isCompleted: Boolean = true,
    val updatedAt: Long = System.currentTimeMillis()
)
