package com.lifenote.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface Phase7Dao {
    @Query("SELECT * FROM gratitude_entries ORDER BY createdAt DESC")
    fun observeGratitude(): Flow<List<GratitudeEntry>>

    @Insert
    suspend fun insertGratitude(entry: GratitudeEntry): Long

    @Query("DELETE FROM gratitude_entries WHERE id = :id")
    suspend fun deleteGratitude(id: Long)

    @Query("SELECT * FROM future_letters ORDER BY unlockAt ASC")
    fun observeFutureLetters(): Flow<List<FutureLetterEntry>>

    @Insert
    suspend fun insertFutureLetter(entry: FutureLetterEntry): Long

    @Query("DELETE FROM future_letters WHERE id = :id")
    suspend fun deleteFutureLetter(id: Long)
}
