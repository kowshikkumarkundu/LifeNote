package com.lifenote.app.ui.phase6

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.Repeat
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lifenote.app.data.local.AppDatabase
import com.lifenote.app.data.local.GoalEntry
import com.lifenote.app.data.local.HabitEntry
import com.lifenote.app.data.local.HabitLogEntry
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun GoalsHabitsScreen() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.getInstance(context).phase6Dao() }
    val scope = rememberCoroutineScope()
    val goals by dao.observeGoals().collectAsState(initial = emptyList())
    val habits by dao.observeHabits().collectAsState(initial = emptyList())
    val todayKey = remember { SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date()) }
    val logs by dao.observeLogsForDate(todayKey).collectAsState(initial = emptyList())
    var section by remember { mutableStateOf("goals") }

    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text("লক্ষ্য ও অভ্যাস", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("ছোট ছোট অগ্রগতিতে নিজের পরিকল্পনা এগিয়ে নাও", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = section == "goals", onClick = { section = "goals" }, label = { Text("জীবনের লক্ষ্য") }, leadingIcon = { Icon(Icons.Outlined.Flag, null) })
            FilterChip(selected = section == "habits", onClick = { section = "habits" }, label = { Text("অভ্যাস ট্র্যাকার") }, leadingIcon = { Icon(Icons.Outlined.Repeat, null) })
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        if (section == "goals") {
            GoalsContent(goals, Modifier.weight(1f),
                onAdd = { scope.launch { dao.insertGoal(it) } },
                onProgress = { goal, progress -> scope.launch { dao.updateGoal(goal.copy(progress = progress, isCompleted = progress >= 100)) } },
                onDelete = { id -> scope.launch { dao.deleteGoal(id) } }
            )
        } else {
            HabitsContent(habits, logs, todayKey, Modifier.weight(1f),
                onAdd = { scope.launch { dao.insertHabit(it) } },
                onToggle = { habit, done -> scope.launch { dao.saveHabitLog(HabitLogEntry(habitId = habit.id, dateKey = todayKey, isCompleted = done)) } },
                onDelete = { id -> scope.launch { dao.deleteHabit(id) } }
            )
        }
    }
}

@Composable
private fun GoalsContent(
    goals: List<GoalEntry>, modifier: Modifier,
    onAdd: (GoalEntry) -> Unit,
    onProgress: (GoalEntry, Int) -> Unit,
    onDelete: (Long) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    LazyColumn(modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("নতুন লক্ষ্য যোগ করো", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("লক্ষ্যের নাম") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("কেন/কীভাবে অর্জন করবে? (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    Button(onClick = { if (title.isNotBlank()) { onAdd(GoalEntry(title = title.trim(), description = description.trim())); title = ""; description = "" } }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("লক্ষ্য সেভ করো") }
                }
            }
        }
        item { Text("আমার লক্ষ্য (${goals.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        if (goals.isEmpty()) item { EmptyState("এখনো কোনো লক্ষ্য যোগ করা হয়নি।") }
        items(goals, key = { it.id }) { goal ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.fillMaxWidth().padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(goal.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                            if (goal.description.isNotBlank()) Text(goal.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        IconButton(onClick = { onDelete(goal.id) }) { Icon(Icons.Outlined.DeleteOutline, contentDescription = "লক্ষ্য মুছে ফেলো") }
                    }
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(if (goal.isCompleted) "সম্পন্ন" else "অগ্রগতি", style = MaterialTheme.typography.labelLarge)
                        Spacer(Modifier.weight(1f))
                        Text("${goal.progress}%", fontWeight = FontWeight.Bold)
                    }
                    LinearProgressIndicator(progress = { goal.progress / 100f }, modifier = Modifier.fillMaxWidth())
                    if (!goal.isCompleted) {
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            listOf(0, 25, 50, 75, 100).forEach { value ->
                                FilterChip(selected = goal.progress == value, onClick = { onProgress(goal, value) }, label = { Text("$value%") })
                            }
                        }
                    } else Text("অভিনন্দন! লক্ষ্যটি সম্পন্ন হয়েছে।", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.bodySmall)
                }
            }
        }
    }
}

@Composable
private fun HabitsContent(
    habits: List<HabitEntry>, logs: List<HabitLogEntry>, todayKey: String, modifier: Modifier,
    onAdd: (HabitEntry) -> Unit,
    onToggle: (HabitEntry, Boolean) -> Unit,
    onDelete: (Long) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var frequency by remember { mutableStateOf("DAILY") }
    val completedIds = remember(logs) { logs.filter { it.isCompleted }.map { it.habitId }.toSet() }
    LazyColumn(modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("নতুন অভ্যাস যোগ করো", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("অভ্যাসের নাম") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(value = description, onValueChange = { description = it }, label = { Text("বিস্তারিত (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth(), minLines = 1)
                    Text("কতবার করবে?", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        FilterChip(selected = frequency == "DAILY", onClick = { frequency = "DAILY" }, label = { Text("প্রতিদিন") })
                        FilterChip(selected = frequency == "WEEKDAYS", onClick = { frequency = "WEEKDAYS" }, label = { Text("রবি–বৃহস্পতি") })
                        FilterChip(selected = frequency == "WEEKLY", onClick = { frequency = "WEEKLY" }, label = { Text("সাপ্তাহিক") })
                    }
                    Button(onClick = { if (title.isNotBlank()) { onAdd(HabitEntry(title = title.trim(), description = description.trim(), frequency = frequency)); title = ""; description = ""; frequency = "DAILY" } }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("অভ্যাস সেভ করো") }
                }
            }
        }
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Text("আজকের অভ্যাস", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Spacer(Modifier.weight(1f))
                Text("${completedIds.size}/${habits.size} সম্পন্ন", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelLarge)
            }
        }
        if (habits.isEmpty()) item { EmptyState("এখনো কোনো অভ্যাস যোগ করা হয়নি।") }
        items(habits, key = { it.id }) { habit ->
            val checked = habit.id in completedIds
            Card(Modifier.fillMaxWidth()) {
                Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Checkbox(checked = checked, onCheckedChange = { onToggle(habit, it) })
                    Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                        Text(habit.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                        if (habit.description.isNotBlank()) Text(habit.description, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        Text("${frequencyLabel(habit.frequency)} · ${if (checked) "আজ সম্পন্ন" else "আজ বাকি"}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                    IconButton(onClick = { onDelete(habit.id) }) { Icon(Icons.Outlined.DeleteOutline, contentDescription = "অভ্যাস মুছে ফেলো") }
                }
            }
        }
        item { Text("তারিখ: $todayKey", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun EmptyState(message: String) {
    Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Outlined.TaskAlt, null, tint = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.width(9.dp)); Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant) } }
}

private fun frequencyLabel(value: String) = when (value) { "WEEKDAYS" -> "রবি–বৃহস্পতি"; "WEEKLY" -> "সাপ্তাহিক"; else -> "প্রতিদিন" }
