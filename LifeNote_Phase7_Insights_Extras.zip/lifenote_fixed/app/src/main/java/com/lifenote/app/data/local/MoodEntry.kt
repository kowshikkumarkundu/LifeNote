package com.lifenote.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "mood_entries")
data class MoodEntry(
    @PrimaryKey val dateKey: String,
    val mood: String,
    val note: String,
    val updatedAt: Long
)
