package com.lifenote.app.ui.phase4

import android.app.DatePickerDialog
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AddAPhoto
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.Mood
import androidx.compose.material.icons.outlined.PhotoLibrary
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import coil.compose.AsyncImage
import com.lifenote.app.data.local.AppDatabase
import com.lifenote.app.data.local.MemoryEntry
import com.lifenote.app.data.local.MoodEntry
import kotlinx.coroutines.launch
import java.io.File
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private data class MoodChoice(val label: String, val emoji: String)
private val moodChoices = listOf(MoodChoice("খুব ভালো", "😄"), MoodChoice("ভালো", "🙂"), MoodChoice("স্বাভাবিক", "😐"), MoodChoice("মন খারাপ", "😔"), MoodChoice("চাপ অনুভব করছি", "😣"))

@Composable
fun Phase4Screen() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.getInstance(context).phase4Dao() }
    val scope = rememberCoroutineScope()
    val moods by dao.observeMoods().collectAsState(initial = emptyList())
    val memories by dao.observeMemories().collectAsState(initial = emptyList())
    var section by remember { mutableStateOf("mood") }
    Column(Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text("নিজের যত্ন ও স্মৃতি", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("মনের অবস্থা লিখে রাখো, বিশেষ মুহূর্তগুলো সংরক্ষণ করো", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(selected = section == "mood", onClick = { section = "mood" }, label = { Text("মুড ট্র্যাকার") }, leadingIcon = { Icon(Icons.Outlined.Mood, null) })
            FilterChip(selected = section == "memory", onClick = { section = "memory" }, label = { Text("বিশেষ স্মৃতি") }, leadingIcon = { Icon(Icons.Outlined.PhotoLibrary, null) })
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        if (section == "mood") MoodContent(moods, modifier = Modifier.weight(1f)) { mood, note ->
            val key = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
            scope.launch { dao.saveMood(MoodEntry(key, mood, note, System.currentTimeMillis())) }
        } else MemoriesContent(memories, modifier = Modifier.weight(1f), onSave = { title, description, date, image ->
            scope.launch { dao.insertMemory(MemoryEntry(title = title, description = description, happenedAt = date, imagePath = image)) }
        }, onDelete = { id -> scope.launch { dao.deleteMemory(id) } })
    }
}

@Composable
private fun MoodContent(moods: List<MoodEntry>, modifier: Modifier = Modifier, onSave: (String, String) -> Unit) {
    val today = remember { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date()) }
    val current = moods.firstOrNull { it.dateKey == today }
    var selected by remember(current?.mood) { mutableStateOf(current?.mood ?: "") }
    var note by remember(current?.note) { mutableStateOf(current?.note ?: "") }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = modifier.fillMaxSize()) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("আজ তোমার কেমন লাগছে?", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    moodChoices.forEach { choice ->
                        FilterChip(selected = selected == choice.label, onClick = { selected = choice.label }, label = { Text("${choice.emoji}  ${choice.label}") }, modifier = Modifier.fillMaxWidth())
                    }
                    OutlinedTextField(note, { note = it }, label = { Text("আজকের অনুভূতি বা কারণ (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                    Button(onClick = { if (selected.isNotBlank()) onSave(selected, note) }, enabled = selected.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text(if (current == null) "আজকের মুড সেভ করো" else "মুড আপডেট করো") }
                }
            }
        }
        item { Text("আগের দিনের মুড", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        if (moods.isEmpty()) item { Text("এখনো কোনো মুড সেভ করা হয়নি।", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(moods, key = { it.dateKey }) { entry ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                val emoji = moodChoices.firstOrNull { it.label == entry.mood }?.emoji ?: "🙂"
                Text("$emoji  ${entry.mood}", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(formatDateKey(entry.dateKey), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                if (entry.note.isNotBlank()) Text(entry.note)
            } }
        }
    }
}

@Composable
private fun MemoriesContent(memories: List<MemoryEntry>, modifier: Modifier = Modifier, onSave: (String, String, Long, String?) -> Unit, onDelete: (Long) -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }
    var description by remember { mutableStateOf("") }
    var happenedAt by remember { mutableStateOf(System.currentTimeMillis()) }
    var imagePath by remember { mutableStateOf<String?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { selectedUri -> runCatching {
            val file = File(context.filesDir, "memory_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(selectedUri)?.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
            if (file.exists() && file.length() > 0) imagePath = file.absolutePath
        } }
    }
    LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp), modifier = modifier.fillMaxSize()) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text("নতুন বিশেষ স্মৃতি", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(title, { title = it }, label = { Text("স্মৃতির শিরোনাম") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(description, { description = it }, label = { Text("বিস্তারিত (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth(), minLines = 3)
                    OutlinedButton(onClick = {
                        val cal = Calendar.getInstance().apply { timeInMillis = happenedAt }
                        DatePickerDialog(context, { _, year, month, day -> cal.set(year, month, day); happenedAt = cal.timeInMillis }, cal.get(Calendar.YEAR), cal.get(Calendar.MONTH), cal.get(Calendar.DAY_OF_MONTH)).show()
                    }, modifier = Modifier.fillMaxWidth()) { Text("তারিখ: ${formatDate(happenedAt)}") }
                    OutlinedButton(onClick = { picker.launch("image/*") }, modifier = Modifier.fillMaxWidth()) { Icon(Icons.Outlined.AddAPhoto, null); Text(if (imagePath == null) "ছবি যোগ করো" else "অন্য ছবি বেছে নাও") }
                    imagePath?.let { AsyncImage(model = it, contentDescription = "স্মৃতির ছবি", modifier = Modifier.fillMaxWidth().height(170.dp)) }
                    Button(onClick = { if (title.isNotBlank()) { onSave(title.trim(), description.trim(), happenedAt, imagePath); title = ""; description = ""; imagePath = null; happenedAt = System.currentTimeMillis() } }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("স্মৃতি সেভ করো") }
                }
            }
        }
        item { Text("সংরক্ষিত স্মৃতি (${memories.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        if (memories.isEmpty()) item { Text("এখনো কোনো বিশেষ স্মৃতি যোগ করা হয়নি।", color = MaterialTheme.colorScheme.onSurfaceVariant) }
        items(memories, key = { it.id }) { memory ->
            Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) { Text(memory.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); Text(formatDate(memory.happenedAt), style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                    IconButton(onClick = { onDelete(memory.id) }) { Icon(Icons.Outlined.DeleteOutline, contentDescription = "মুছে ফেলো") }
                }
                if (memory.description.isNotBlank()) Text(memory.description)
                memory.imagePath?.let { AsyncImage(model = it, contentDescription = "স্মৃতির ছবি", modifier = Modifier.fillMaxWidth().height(190.dp)) }
            } }
        }
    }
}

private fun formatDate(time: Long): String = SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(time))
private fun formatDateKey(key: String): String = runCatching { SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).parse(key)?.let { formatDate(it.time) } ?: key }.getOrDefault(key)
