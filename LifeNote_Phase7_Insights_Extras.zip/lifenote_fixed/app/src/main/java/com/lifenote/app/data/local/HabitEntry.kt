package com.lifenote.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "habits")
data class HabitEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val description: String = "",
    val frequency: String = "DAILY",
    val createdAt: Long = System.currentTimeMillis(),
    val isArchived: Boolean = false
)
