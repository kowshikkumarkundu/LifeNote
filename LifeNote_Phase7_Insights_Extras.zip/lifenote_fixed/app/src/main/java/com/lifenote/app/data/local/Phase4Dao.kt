package com.lifenote.app.data.local

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import kotlinx.coroutines.flow.Flow

@Dao
interface Phase4Dao {
    @Query("SELECT * FROM mood_entries ORDER BY dateKey DESC")
    fun observeMoods(): Flow<List<MoodEntry>>

    @Query("SELECT * FROM mood_entries WHERE dateKey = :dateKey LIMIT 1")
    suspend fun getMood(dateKey: String): MoodEntry?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun saveMood(entry: MoodEntry)

    @Query("SELECT * FROM memory_entries ORDER BY happenedAt DESC, id DESC")
    fun observeMemories(): Flow<List<MemoryEntry>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertMemory(entry: MemoryEntry): Long

    @Query("DELETE FROM memory_entries WHERE id = :id")
    suspend fun deleteMemory(id: Long)
}
