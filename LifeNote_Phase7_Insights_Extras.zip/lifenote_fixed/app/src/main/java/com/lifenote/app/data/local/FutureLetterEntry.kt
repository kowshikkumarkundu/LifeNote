package com.lifenote.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "future_letters")
data class FutureLetterEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val body: String,
    val unlockAt: Long,
    val createdAt: Long
)
