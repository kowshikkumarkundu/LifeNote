package com.lifenote.app.reminders

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.os.Build
import com.lifenote.app.MainActivity
import com.lifenote.app.data.local.ReminderEntry
import java.util.Calendar
import kotlinx.coroutines.launch

object ReminderScheduler {
    private const val CHANNEL_ID = "lifenote_reminders"
    const val EXTRA_ID = "reminder_id"
    const val EXTRA_TITLE = "reminder_title"
    const val EXTRA_NOTE = "reminder_note"
    const val EXTRA_REPEAT = "reminder_repeat"

    fun schedule(context: Context, reminder: ReminderEntry) {
        createChannel(context)
        val intent = Intent(context, ReminderReceiver::class.java).apply {
            putExtra(EXTRA_ID, reminder.id)
            putExtra(EXTRA_TITLE, reminder.title)
            putExtra(EXTRA_NOTE, reminder.note)
            putExtra(EXTRA_REPEAT, reminder.repeatType)
        }
        val pending = PendingIntent.getBroadcast(
            context, reminder.id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val alarm = context.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        alarm.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, reminder.triggerAt.coerceAtLeast(System.currentTimeMillis() + 1000L), pending)
    }

    fun cancel(context: Context, reminder: ReminderEntry) {
        val intent = Intent(context, ReminderReceiver::class.java)
        val pending = PendingIntent.getBroadcast(
            context, reminder.id.toInt(), intent,
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        (context.getSystemService(Context.ALARM_SERVICE) as AlarmManager).cancel(pending)
    }

    fun createChannel(context: Context) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            manager.createNotificationChannel(NotificationChannel(CHANNEL_ID, "LifeNote Reminders", NotificationManager.IMPORTANCE_DEFAULT).apply {
                description = "Local reminders created in LifeNote"
            })
        }
    }

    fun nextOccurrence(time: Long, repeatType: String): Long? {
        val cal = Calendar.getInstance().apply { timeInMillis = time }
        when (repeatType) {
            "DAILY" -> cal.add(Calendar.DAY_OF_YEAR, 1)
            "WEEKLY" -> cal.add(Calendar.WEEK_OF_YEAR, 1)
            "MONTHLY" -> cal.add(Calendar.MONTH, 1)
            else -> return null
        }
        return cal.timeInMillis
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        val id = intent.getLongExtra(ReminderScheduler.EXTRA_ID, 0L)
        val title = intent.getStringExtra(ReminderScheduler.EXTRA_TITLE).orEmpty().ifBlank { "LifeNote Reminder" }
        val note = intent.getStringExtra(ReminderScheduler.EXTRA_NOTE).orEmpty()
        val repeat = intent.getStringExtra(ReminderScheduler.EXTRA_REPEAT) ?: "NONE"
        ReminderScheduler.createChannel(context)

        val openApp = PendingIntent.getActivity(
            context, id.toInt(), Intent(context, MainActivity::class.java),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val builder = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            android.app.Notification.Builder(context, "lifenote_reminders")
        } else {
            @Suppress("DEPRECATION")
            android.app.Notification.Builder(context)
        }
        val notification = builder.setSmallIcon(android.R.drawable.ic_dialog_info)
            .setContentTitle(title)
            .setContentText(note.ifBlank { "তোমার রিমাইন্ডারের সময় হয়েছে" })
            .setStyle(android.app.Notification.BigTextStyle().bigText(note.ifBlank { "তোমার রিমাইন্ডারের সময় হয়েছে" }))
            .setAutoCancel(true)
            .setContentIntent(openApp)
            .build()
        val manager = context.getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        runCatching { manager.notify(id.toInt(), notification) }

        val pending = goAsync()
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                val dao = com.lifenote.app.data.local.AppDatabase.getInstance(context).phase5Dao()
                val saved = dao.getReminder(id)
                if (saved != null && saved.isEnabled) {
                    val next = ReminderScheduler.nextOccurrence(System.currentTimeMillis(), repeat)
                    if (next != null) {
                        val updated = saved.copy(triggerAt = next)
                        dao.updateReminder(updated)
                        ReminderScheduler.schedule(context, updated)
                    } else {
                        dao.updateReminder(saved.copy(isEnabled = false))
                    }
                }
            } finally { pending.finish() }
        }
    }
}

class ReminderBootReceiver : BroadcastReceiver() {
    override fun onReceive(context: Context, intent: Intent) {
        if (intent.action != Intent.ACTION_BOOT_COMPLETED) return
        val pending = goAsync()
        kotlinx.coroutines.CoroutineScope(kotlinx.coroutines.Dispatchers.IO).launch {
            try {
                val dao = com.lifenote.app.data.local.AppDatabase.getInstance(context).phase5Dao()
                dao.getEnabledReminders().forEach { reminder ->
                    if (reminder.triggerAt > System.currentTimeMillis()) ReminderScheduler.schedule(context, reminder)
                    else {
                        val next = ReminderScheduler.nextOccurrence(reminder.triggerAt, reminder.repeatType)
                        if (next != null) ReminderScheduler.schedule(context, reminder.copy(triggerAt = next))
                    }
                }
            } finally { pending.finish() }
        }
    }
}
