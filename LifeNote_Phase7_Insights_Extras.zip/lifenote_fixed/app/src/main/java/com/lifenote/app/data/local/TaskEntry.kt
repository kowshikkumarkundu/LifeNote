package com.lifenote.app.data.local

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "tasks")
data class TaskEntry(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val title: String,
    val note: String = "",
    val dueAt: Long? = null,
    val priority: String = "মাঝারি",
    val isCompleted: Boolean = false,
    val repeatType: String = "NONE",
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)
