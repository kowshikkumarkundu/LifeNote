package com.lifenote.app.ui.phase7

import android.graphics.Paint
import android.graphics.Typeface
import android.graphics.pdf.PdfDocument
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material.icons.outlined.Favorite
import androidx.compose.material.icons.outlined.Lock
import androidx.compose.material.icons.outlined.PictureAsPdf
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.lifenote.app.data.local.*
import kotlinx.coroutines.launch
import java.io.OutputStream
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun Phase7Screen() {
    val context = LocalContext.current
    val db = remember { AppDatabase.getInstance(context) }
    val scope = rememberCoroutineScope()
    val gratitude by db.phase7Dao().observeGratitude().collectAsState(initial = emptyList())
    val letters by db.phase7Dao().observeFutureLetters().collectAsState(initial = emptyList())
    val diaries by db.diaryEntryDao().observeAll().collectAsState(initial = emptyList())
    var section by remember { mutableStateOf("overview") }
    var gratitudeText by remember { mutableStateOf("") }
    var showLetter by remember { mutableStateOf(false) }
    var letterTitle by remember { mutableStateOf("") }
    var letterBody by remember { mutableStateOf("") }
    var unlockDays by remember { mutableStateOf("30") }
    var exportEntries by remember { mutableStateOf<List<DiaryEntry>>(emptyList()) }
    val pdfLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/pdf")) { uri ->
        if (uri != null) try {
            context.contentResolver.openOutputStream(uri)?.use { createDiaryPdf(exportEntries, it) }
                ?: throw IllegalStateException("ফাইল তৈরি করা যায়নি")
            Toast.makeText(context, "PDF সেভ হয়েছে", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(context, e.message ?: "PDF তৈরি করা যায়নি", Toast.LENGTH_LONG).show() }
    }
    val today = Calendar.getInstance()
    val onThisDay = diaries.filter { e -> Calendar.getInstance().apply { timeInMillis = e.createdAt }.let { it.get(Calendar.MONTH) == today.get(Calendar.MONTH) && it.get(Calendar.DAY_OF_MONTH) == today.get(Calendar.DAY_OF_MONTH) && it.get(Calendar.YEAR) < today.get(Calendar.YEAR) } }
    val favorites = diaries.filter { it.isFavorite }
    val wordCount = diaries.sumOf { it.content.trim().split(Regex("\\s+")).count(String::isNotBlank) }
    val quotes = listOf("ছোট ছোট পদক্ষেপই একদিন বড় পরিবর্তন আনে।", "নিজের গতিতে এগিয়ে যাওয়াও এগিয়ে যাওয়া।", "আজকের একটি ভালো সিদ্ধান্ত আগামীকালকে সুন্দর করতে পারে।", "প্রতিদিন নতুন করে শুরু করার সুযোগ থাকে।", "কৃতজ্ঞতা সাধারণ দিনকেও বিশেষ করে তোলে।")
    val quote = quotes[today.get(Calendar.DAY_OF_YEAR) % quotes.size]

    if (showLetter) AlertDialog(
        onDismissRequest = { showLetter = false }, title = { Text("ভবিষ্যতের নিজের কাছে চিঠি") },
        text = { Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedTextField(letterTitle, { letterTitle = it }, label = { Text("চিঠির শিরোনাম") }, singleLine = true)
            OutlinedTextField(letterBody, { letterBody = it }, label = { Text("তোমার বার্তা") }, minLines = 4)
            OutlinedTextField(unlockDays, { unlockDays = it.filter(Char::isDigit).take(4) }, label = { Text("কত দিন পর খুলবে?") }, singleLine = true)
        } },
        confirmButton = { TextButton(onClick = {
            if (letterTitle.isNotBlank() && letterBody.isNotBlank()) {
                val days = (unlockDays.toIntOrNull() ?: 30).coerceIn(1, 3650)
                scope.launch { db.phase7Dao().insertFutureLetter(FutureLetterEntry(title = letterTitle.trim(), body = letterBody.trim(), unlockAt = System.currentTimeMillis() + days * 86_400_000L, createdAt = System.currentTimeMillis())) }
                letterTitle = ""; letterBody = ""; unlockDays = "30"; showLetter = false
            }
        }) { Text("সংরক্ষণ") } }, dismissButton = { TextButton(onClick = { showLetter = false }) { Text("বাতিল") } }
    )

    LazyColumn(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item { Text("জীবনের মুহূর্ত", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold) }
        item { Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
            listOf("overview" to "সংক্ষিপ্ত", "gratitude" to "কৃতজ্ঞতা", "letters" to "ভবিষ্যতের চিঠি").forEach { (key, label) ->
                if (section == key) Button(onClick = { section = key }, contentPadding = PaddingValues(horizontal = 10.dp, vertical = 8.dp)) { Text(label) }
                else TextButton(onClick = { section = key }, contentPadding = PaddingValues(horizontal = 8.dp, vertical = 8.dp)) { Text(label) }
            }
        } }
        if (section == "overview") {
            item { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer), modifier = Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp)) {
                Row { Icon(Icons.Outlined.AutoAwesome, null); Text("  আজকের অনুপ্রেরণা", fontWeight = FontWeight.SemiBold) }
                Text(quote, style = MaterialTheme.typography.titleMedium)
            } } }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("তোমার LifeNote পরিসংখ্যান", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text("মোট ডায়েরি: ${diaries.size}টি")
                Text("লেখা শব্দ: $wordCount")
                Text("প্রিয় ডায়েরি: ${favorites.size}টি")
                Text("কৃতজ্ঞতার নোট: ${gratitude.size}টি")
            } } }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("এই দিনে, আগের বছর", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                if (onThisDay.isEmpty()) Text("আগের বছরের এই দিনে কোনো ডায়েরি পাওয়া যায়নি।", color = MaterialTheme.colorScheme.secondary)
                onThisDay.forEach { e -> Text("${e.title.ifBlank { "শিরোনামহীন ডায়েরি" }} · ${formatDate(e.createdAt)}\n${e.content.take(140)}") }
            } } }
            item { Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Row { Icon(Icons.Outlined.Favorite, null); Text("  প্রিয় ডায়েরি (${favorites.size})", fontWeight = FontWeight.SemiBold) }
                if (favorites.isEmpty()) Text("ডায়েরি পড়ার সময় Favorite চিহ্ন দিলে এখানে দেখা যাবে।")
                favorites.take(8).forEach { Text("• ${it.title.ifBlank { "শিরোনামহীন ডায়েরি" }}") }
            } } }
            item { Column {
                Button(onClick = { exportEntries = diaries; pdfLauncher.launch("LifeNote_Diary_Export.pdf") }, modifier = Modifier.fillMaxWidth(), enabled = diaries.isNotEmpty()) {
                    Icon(Icons.Outlined.PictureAsPdf, null); Text("  সব ডায়েরি PDF হিসেবে Export")
                }
                Text("PDF-এ শিরোনাম, তারিখ ও লেখা থাকবে; সংযুক্ত ছবি ও অডিও থাকবে না।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            } }
        } else if (section == "gratitude") {
            item { Text("আজ কোন বিষয়গুলো তোমাকে কৃতজ্ঞ করেছে?", style = MaterialTheme.typography.titleMedium) }
            item { Column {
                OutlinedTextField(gratitudeText, { gratitudeText = it }, modifier = Modifier.fillMaxWidth(), minLines = 3, label = { Text("আজকের কৃতজ্ঞতার কথা") })
                Button(onClick = { if (gratitudeText.isNotBlank()) scope.launch { db.phase7Dao().insertGratitude(GratitudeEntry(body = gratitudeText.trim(), createdAt = System.currentTimeMillis())); gratitudeText = "" } }, enabled = gratitudeText.isNotBlank()) { Text("সংরক্ষণ") }
            } }
            if (gratitude.isEmpty()) item { Text("এখনো কোনো কৃতজ্ঞতার নোট নেই।") }
            items(gratitude, key = { it.id }) { g -> Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp)) {
                Text(formatDate(g.createdAt), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                Text(g.body)
                TextButton(onClick = { scope.launch { db.phase7Dao().deleteGratitude(g.id) } }) { Text("মুছে ফেলো") }
            } } }
        } else {
            item { Column {
                Text("নিজের ভবিষ্যতের জন্য একটি বার্তা রেখে দাও। নির্ধারিত সময়ের আগে সেটি লুকানো থাকবে।")
                Button(onClick = { showLetter = true }) { Text("নতুন চিঠি লিখুন") }
            } }
            if (letters.isEmpty()) item { Text("এখনো কোনো চিঠি লেখা হয়নি।") }
            items(letters, key = { it.id }) { l ->
                val unlocked = l.unlockAt <= System.currentTimeMillis()
                Card(Modifier.fillMaxWidth()) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                    Row { Text(l.title, Modifier.weight(1f), fontWeight = FontWeight.SemiBold); if (!unlocked) Icon(Icons.Outlined.Lock, "Locked") }
                    if (unlocked) Text(l.body) else Text("${formatDate(l.unlockAt)} তারিখে খুলতে পারবে।", color = MaterialTheme.colorScheme.secondary)
                    TextButton(onClick = { scope.launch { db.phase7Dao().deleteFutureLetter(l.id) } }) { Text("মুছে ফেলো") }
                } }
            }
        }
    }
}

private fun formatDate(time: Long) = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(time))

private fun createDiaryPdf(entries: List<DiaryEntry>, output: OutputStream) {
    val pdf = PdfDocument()
    val titlePaint = Paint().apply { textSize = 18f; typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD); isAntiAlias = true }
    val bodyPaint = Paint().apply { textSize = 11f; isAntiAlias = true }
    val datePaint = Paint().apply { textSize = 9f; isAntiAlias = true }
    var pageNumber = 1
    entries.forEach { entry ->
        var page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber++).create())
        var canvas = page.canvas
        var y = 52f
        canvas.drawText(entry.title.ifBlank { "Untitled diary" }.take(70), 40f, y, titlePaint); y += 24f
        canvas.drawText(SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(entry.createdAt)), 40f, y, datePaint); y += 28f
        val words = entry.content.replace('\n', ' ').split(Regex("\\s+")).filter { it.isNotBlank() }
        var line = StringBuilder()
        for (word in words) {
            val candidate = if (line.isEmpty()) word else "$line $word"
            if (bodyPaint.measureText(candidate) > 510f && line.isNotEmpty()) {
                if (y > 800f) {
                    pdf.finishPage(page)
                    page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber++).create())
                    canvas = page.canvas; y = 48f
                }
                canvas.drawText(line.toString(), 40f, y, bodyPaint); y += 18f
                line = StringBuilder(word)
            } else line = StringBuilder(candidate)
        }
        if (line.isNotEmpty()) {
            if (y > 800f) {
                pdf.finishPage(page)
                page = pdf.startPage(PdfDocument.PageInfo.Builder(595, 842, pageNumber++).create())
                canvas = page.canvas; y = 48f
            }
            canvas.drawText(line.toString(), 40f, y, bodyPaint)
        }
        pdf.finishPage(page)
    }
    pdf.writeTo(output)
    pdf.close()
}
