package com.lifenote.app.ui.diary

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaPlayer
import android.media.MediaRecorder
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.ArrowBack
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Edit
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Pause
import androidx.compose.material.icons.outlined.PlayArrow
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.onFocusChanged
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage
import com.lifenote.app.data.local.DiaryEntry
import kotlinx.coroutines.delay
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private sealed class DiaryBlock {
    data class Paragraph(val text: String) : DiaryBlock()
    data class Picture(val path: String) : DiaryBlock()
    data class Audio(val path: String) : DiaryBlock()
}

private fun encodeBlocks(blocks: List<DiaryBlock>): String = JSONArray().apply {
    blocks.forEach { block ->
        put(JSONObject().apply {
            when (block) {
                is DiaryBlock.Paragraph -> { put("type", "text"); put("value", block.text) }
                is DiaryBlock.Picture -> { put("type", "image"); put("value", block.path) }
                is DiaryBlock.Audio -> { put("type", "audio"); put("value", block.path) }
            }
        })
    }
}.toString()

private fun decodeBlocks(entry: DiaryEntry): List<DiaryBlock> {
    val raw = entry.contentBlocks
    if (!raw.isNullOrBlank()) {
        try {
            val array = JSONArray(raw)
            val result = mutableListOf<DiaryBlock>()
            for (i in 0 until array.length()) {
                val item = array.getJSONObject(i)
                val value = item.optString("value")
                when (item.optString("type")) {
                    "text" -> result.add(DiaryBlock.Paragraph(value))
                    "image" -> result.add(DiaryBlock.Picture(value))
                    "audio" -> result.add(DiaryBlock.Audio(value))
                }
            }
            if (result.isNotEmpty()) return result
        } catch (_: Exception) { }
    }
    return buildList {
        if (entry.content.isNotBlank()) add(DiaryBlock.Paragraph(entry.content))
        entry.imagePath?.let { add(DiaryBlock.Picture(it)) }
        entry.voiceNotePath?.let { add(DiaryBlock.Audio(it)) }
        if (isEmpty()) add(DiaryBlock.Paragraph(""))
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiaryScreen(viewModel: DiaryViewModel = viewModel()) {
    val context = LocalContext.current
    val entries by viewModel.entries.collectAsState()
    var editing by remember { mutableStateOf(false) }
    var selectedEntry by remember { mutableStateOf<DiaryEntry?>(null) }
    var entryId by remember { mutableStateOf(0L) }
    var createdAt by remember { mutableStateOf(System.currentTimeMillis()) }
    var title by remember { mutableStateOf("") }
    val blocks = remember { mutableStateListOf<DiaryBlock>() }
    var activeTextIndex by remember { mutableIntStateOf(0) }
    var showDelete by remember { mutableStateOf<DiaryEntry?>(null) }
    var recording by remember { mutableStateOf(false) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var pendingAudioFile by remember { mutableStateOf<File?>(null) }

    fun startNew() {
        selectedEntry = null; entryId = 0L; createdAt = System.currentTimeMillis()
        title = ""; blocks.clear(); blocks.add(DiaryBlock.Paragraph("")); activeTextIndex = 0
        editing = true
    }
    fun openEntry(entry: DiaryEntry) {
        selectedEntry = entry; entryId = entry.id; createdAt = entry.createdAt; title = entry.title
        blocks.clear(); blocks.addAll(decodeBlocks(entry))
        activeTextIndex = blocks.indexOfLast { it is DiaryBlock.Paragraph }.coerceAtLeast(0)
        editing = false
    }
    fun saveNow(onDone: (() -> Unit)? = null) {
        val plainText = blocks.filterIsInstance<DiaryBlock.Paragraph>().joinToString("\n\n") { it.text }
        if (title.isBlank() && plainText.isBlank() && blocks.none { it !is DiaryBlock.Paragraph }) return
        val firstImage = blocks.filterIsInstance<DiaryBlock.Picture>().firstOrNull()?.path
        val firstAudio = blocks.filterIsInstance<DiaryBlock.Audio>().firstOrNull()?.path
        val savedBlocks = encodeBlocks(blocks.toList())
        val savedEntry = DiaryEntry(entryId, createdAt, System.currentTimeMillis(), title, plainText, firstImage, firstAudio, savedBlocks)
        viewModel.save(savedEntry) { id ->
            entryId = id
            if (onDone != null) selectedEntry = savedEntry.copy(id = id)
            onDone?.invoke()
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            val file = File(context.filesDir, "diary_image_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(it)?.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
            val insertAt = (activeTextIndex + 1).coerceIn(0, blocks.size)
            blocks.add(insertAt, DiaryBlock.Picture(file.absolutePath))
        }
    }
    fun beginRecording() {
        val file = File(context.filesDir, "voice_${System.currentTimeMillis()}.m4a")
        try {
            val r = MediaRecorder()
            r.setAudioSource(MediaRecorder.AudioSource.MIC)
            r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
            r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
            r.setOutputFile(file.absolutePath); r.prepare(); r.start()
            recorder = r; pendingAudioFile = file; recording = true
        } catch (_: Exception) { try { recorder?.release() } catch (_: Exception) { }; recorder = null; recording = false }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted -> if (granted) beginRecording() }

    LaunchedEffect(editing, title, blocks.map { when (it) { is DiaryBlock.Paragraph -> it.text; is DiaryBlock.Picture -> it.path; is DiaryBlock.Audio -> it.path } }) {
        if (editing && (title.isNotBlank() || blocks.any { it !is DiaryBlock.Paragraph || (it as? DiaryBlock.Paragraph)?.text?.isNotBlank() == true })) {
            delay(1000); saveNow()
        }
    }
    DisposableEffect(Unit) {
        onDispose { try { if (recording) recorder?.stop() } catch (_: Exception) { }; try { recorder?.release() } catch (_: Exception) { } }
    }

    if (showDelete != null) AlertDialog(
        onDismissRequest = { showDelete = null }, title = { Text("ডায়েরি মুছে ফেলবে?") },
        text = { Text("এই এন্ট্রিটি মুছে ফেলা হবে।") },
        confirmButton = { TextButton(onClick = { showDelete?.let(viewModel::delete); if (selectedEntry?.id == showDelete?.id) selectedEntry = null; showDelete = null }) { Text("মুছে ফেলো") } },
        dismissButton = { TextButton(onClick = { showDelete = null }) { Text("বাতিল") } }
    )

    when {
        editing -> {
            LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp, vertical = 10.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { editing = false; if (entryId == 0L) selectedEntry = null }) { Icon(Icons.Outlined.ArrowBack, "Back") }
                        Text(if (entryId == 0L) "নতুন ডায়েরি লিখুন" else "ডায়েরি সম্পাদনা", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    }
                    Text("${formatDate(createdAt)} · ${formatTime(createdAt)}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                }
                item { OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("শিরোনাম") }, modifier = Modifier.fillMaxWidth(), singleLine = true) }
                itemsIndexed(blocks) { index, block ->
                    when (block) {
                        is DiaryBlock.Paragraph -> {
                            OutlinedTextField(value = block.text, onValueChange = { value -> blocks[index] = DiaryBlock.Paragraph(value); activeTextIndex = index }, label = { Text("প্যারাগ্রাফ") }, modifier = Modifier.fillMaxWidth().onFocusChanged { if (it.isFocused) activeTextIndex = index }, minLines = 4)
                            TextButton(onClick = { activeTextIndex = index; blocks.add(index + 1, DiaryBlock.Paragraph("")) }) { Icon(Icons.Outlined.Add, null); Text("এর পর নতুন প্যারাগ্রাফ") }
                        }
                        is DiaryBlock.Picture -> {
                            Card(modifier = Modifier.fillMaxWidth()) {
                                Column(Modifier.padding(10.dp)) {
                                    AsyncImage(model = File(block.path), contentDescription = "সংযুক্ত ছবি", modifier = Modifier.fillMaxWidth().height(210.dp).clip(RoundedCornerShape(12.dp)), contentScale = ContentScale.Crop)
                                    TextButton(onClick = { blocks.removeAt(index) }) { Icon(Icons.Outlined.Delete, null); Text("ছবি সরান") }
                                }
                            }
                        }
                        is DiaryBlock.Audio -> {
                            AudioPlayerCard(path = block.path, editable = true, onRemove = { blocks.removeAt(index) })
                        }
                    }
                }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("মিডিয়া যোগ করুন", style = MaterialTheme.typography.titleSmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = { imagePicker.launch("image/*") }) { Icon(Icons.Outlined.Image, null); Text("ছবি") }
                                Button(onClick = {
                                    if (recording) {
                                        try { recorder?.stop(); recorder?.release(); pendingAudioFile?.let { blocks.add((activeTextIndex + 1).coerceIn(0, blocks.size), DiaryBlock.Audio(it.absolutePath)) } } catch (_: Exception) { pendingAudioFile?.delete() }
                                        recorder = null; recording = false
                                    } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) beginRecording()
                                    else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                                }) { Icon(if (recording) Icons.Outlined.Stop else Icons.Outlined.Mic, null); Text(if (recording) "রেকর্ডিং বন্ধ" else "ভয়েস রেকর্ড") }
                            }
                            if (recording) Text("রেকর্ডিং চলছে… বন্ধ করলে ভয়েস নোট যুক্ত হবে।", color = MaterialTheme.colorScheme.error)
                        }
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                        Button(onClick = {
                            if (recording) { try { recorder?.stop(); recorder?.release(); pendingAudioFile?.let { blocks.add(DiaryBlock.Audio(it.absolutePath)) } } catch (_: Exception) { pendingAudioFile?.delete() }; recorder = null; recording = false }
                            saveNow { editing = false }
                        }) { Text("Save / সম্পন্ন") }
                        TextButton(onClick = { if (recording) { try { recorder?.stop() } catch (_: Exception) { }; try { recorder?.release() } catch (_: Exception) { }; recorder = null; recording = false }; editing = false }) { Text("বন্ধ") }
                    }
                    Text("পরিবর্তন স্বয়ংক্রিয়ভাবেও সংরক্ষিত হয়", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
                }
            }
        }
        selectedEntry != null -> {
            val entry = selectedEntry!!
            LazyColumn(modifier = Modifier.fillMaxSize().padding(horizontal = 18.dp, vertical = 12.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column(Modifier.weight(1f)) {
                            Text(entry.title.ifBlank { "শিরোনামহীন ডায়েরি" }, style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                            Spacer(Modifier.height(5.dp))
                            Text("${formatDate(entry.createdAt)} · ${formatTime(entry.createdAt)}", style = MaterialTheme.typography.labelMedium, color = MaterialTheme.colorScheme.secondary)
                        }
                        TextButton(onClick = { openEntry(entry) }) { Icon(Icons.Outlined.Edit, null); Text("Edit") }
                    }
                    TextButton(onClick = { selectedEntry = null }) { Icon(Icons.Outlined.ArrowBack, null); Text("সব ডায়েরি") }
                }
                items(decodeBlocks(entry)) { block ->
                    when (block) {
                        is DiaryBlock.Paragraph -> if (block.text.isNotBlank()) Text(block.text, style = MaterialTheme.typography.bodyLarge, lineHeight = MaterialTheme.typography.bodyLarge.lineHeight * 1.35f)
                        is DiaryBlock.Picture -> AsyncImage(model = File(block.path), contentDescription = "ডায়েরির ছবি", modifier = Modifier.fillMaxWidth().clip(RoundedCornerShape(14.dp)), contentScale = ContentScale.FillWidth)
                        is DiaryBlock.Audio -> AudioPlayerCard(path = block.path)
                    }
                }
                item { TextButton(onClick = { showDelete = entry }) { Icon(Icons.Outlined.Delete, null); Text("ডায়েরি মুছুন") } }
            }
        }
        else -> {
            Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween, verticalAlignment = Alignment.CenterVertically) {
                    Column { Text("আমার ডায়েরি", style = MaterialTheme.typography.headlineSmall); Text("${entries.size}টি এন্ট্রি", style = MaterialTheme.typography.bodySmall) }
                    Button(onClick = ::startNew) { Icon(Icons.Outlined.Add, null); Text("নতুন লেখা") }
                }
                if (entries.isEmpty()) Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Text("এখনো কোনো ডায়েরি লেখা হয়নি। আজকের দিনটি দিয়ে শুরু করো।", modifier = Modifier.padding(18.dp))
                } else LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(entries, key = { it.id }) { entry ->
                        Card(modifier = Modifier.fillMaxWidth().clickable { openEntry(entry) }, shape = RoundedCornerShape(14.dp)) {
                            Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(entry.title.ifBlank { "শিরোনামহীন ডায়েরি" }, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                    IconButton(onClick = { showDelete = entry }) { Icon(Icons.Outlined.Delete, "Delete") }
                                }
                                Text("${formatDate(entry.createdAt)} · ${formatTime(entry.createdAt)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                Text(entry.content.take(180), maxLines = 3, style = MaterialTheme.typography.bodyMedium)
                                if (entry.imagePath != null || entry.voiceNotePath != null || !entry.contentBlocks.isNullOrBlank()) Text("ছবি / ভয়েস সংযুক্তি থাকতে পারে", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun AudioPlayerCard(path: String, editable: Boolean = false, onRemove: (() -> Unit)? = null) {
    var playing by remember(path) { mutableStateOf(false) }
    var player by remember(path) { mutableStateOf<MediaPlayer?>(null) }
    DisposableEffect(path) { onDispose { try { player?.release() } catch (_: Exception) { }; player = null } }
    Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(16.dp), modifier = Modifier.fillMaxWidth()) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = {
                if (playing) { player?.pause(); playing = false }
                else {
                    try {
                        if (player == null) player = MediaPlayer().apply { setDataSource(path); setOnCompletionListener { playing = false; it.seekTo(0) }; prepare() }
                        player?.start(); playing = true
                    } catch (_: Exception) { playing = false }
                }
            }, modifier = Modifier.size(46.dp).background(MaterialTheme.colorScheme.primary, CircleShape)) {
                Icon(if (playing) Icons.Outlined.Pause else Icons.Outlined.PlayArrow, contentDescription = if (playing) "Pause" else "Play", tint = MaterialTheme.colorScheme.onPrimary)
            }
            Spacer(Modifier.width(12.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(5.dp)) {
                Text("Voice note", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Row(horizontalArrangement = Arrangement.spacedBy(3.dp), verticalAlignment = Alignment.CenterVertically, modifier = Modifier.height(28.dp)) {
                    val heights = listOf(8, 15, 22, 12, 26, 17, 10, 21, 27, 14, 8, 19, 25, 12, 17, 9, 23, 14, 27, 11, 18, 8, 21, 14)
                    heights.forEachIndexed { index, h ->
                        Box(Modifier.width(3.dp).height(h.dp).clip(RoundedCornerShape(3.dp)).background(if (playing && index < 12) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outlineVariant))
                    }
                }
                Text(if (playing) "Playing…" else "Tap play to listen", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
            }
            if (editable && onRemove != null) IconButton(onClick = onRemove) { Icon(Icons.Outlined.Delete, "Remove voice note") }
        }
    }
}

private fun formatDate(time: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(time))
private fun formatTime(time: Long): String = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(time))
