# LifeNote - Phase 1

Personal offline-first Android diary and life management app foundation.

## Build on GitHub Actions

The repository is configured to build without a Gradle Wrapper. GitHub Actions installs Gradle 8.13 and Android SDK platform/build-tools 36, then runs `gradle assembleDebug`.

1. Upload the contents of this folder to the root of your GitHub repository (do not upload the enclosing folder).
2. Open the Actions tab.
3. Run **Build LifeNote APK** or push a commit to `main`.
4. Download the `LifeNote-APK` artifact from a successful run.

## Requirements
- JDK 17
- Gradle 8.13
- Android SDK 36
