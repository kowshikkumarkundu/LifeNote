# LifeNote — Phase 4: Mood Tracker & Memories

Phase 4 adds a daily mood journal and a personal special-moments collection on top of the working Phase 3 diary and calendar.

## Included
- Daily mood check-in with five mood choices and an optional note
- One mood record per local calendar day; today's entry can be updated
- Previous mood history, ordered newest first
- Special memories with title, optional description, selectable date, and optional photo
- Memory photos copied into the app's private internal storage
- Saved memory list and delete action
- New Room database migration from version 3 to 4; existing diary entries, calendar data, image paths, and voice-note paths are retained
- Existing Phase 3 diary, search, calendar, and scrolling behavior retained
- Offline-first; no login, backend, cloud sync, ads, or analytics

## Build on GitHub Actions
1. Remove the previous project ZIP from the repository root before uploading this one.
2. Upload this ZIP to the repository root.
3. Keep the existing repository workflow file unchanged.
4. Run the **Build LifeNote APK** workflow and download the APK artifact after a successful run.

Build requirements: JDK 17, Gradle 8.13, Android SDK 36.
