package com.lifenote.app.security

import android.content.Context
import android.util.Base64
import java.security.SecureRandom
import javax.crypto.SecretKeyFactory
import javax.crypto.spec.PBEKeySpec

object SecurityStore {
    private const val PREF = "lifenote_security"
    private const val SALT = "pin_salt"
    private const val HASH = "pin_hash"
    fun hasPin(context: Context) = context.getSharedPreferences(PREF, 0).contains(HASH)
    fun setPin(context: Context, pin: String) {
        val salt = ByteArray(16).also { SecureRandom().nextBytes(it) }
        val hash = derive(pin, salt)
        context.getSharedPreferences(PREF, 0).edit().putString(SALT, Base64.encodeToString(salt, Base64.NO_WRAP)).putString(HASH, Base64.encodeToString(hash, Base64.NO_WRAP)).apply()
    }
    fun verify(context: Context, pin: String): Boolean {
        val p = context.getSharedPreferences(PREF, 0)
        val salt = p.getString(SALT, null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return false
        val expected = p.getString(HASH, null)?.let { Base64.decode(it, Base64.NO_WRAP) } ?: return false
        return java.security.MessageDigest.isEqual(expected, derive(pin, salt))
    }
    fun removePin(context: Context) { context.getSharedPreferences(PREF, 0).edit().clear().apply() }
    private fun derive(pin: String, salt: ByteArray): ByteArray {
        val spec = PBEKeySpec(pin.toCharArray(), salt, 120_000, 256)
        return SecretKeyFactory.getInstance("PBKDF2WithHmacSHA256").generateSecret(spec).encoded
    }
}
