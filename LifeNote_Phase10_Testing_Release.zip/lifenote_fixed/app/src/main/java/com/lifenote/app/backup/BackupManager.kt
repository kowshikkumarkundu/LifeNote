package com.lifenote.app.backup

import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import com.lifenote.app.data.local.AppDatabase
import java.io.BufferedInputStream
import java.io.BufferedOutputStream
import java.io.File
import java.io.FileInputStream
import java.io.FileOutputStream
import java.util.zip.ZipEntry
import java.util.zip.ZipInputStream
import java.util.zip.ZipOutputStream

/** Backup format: lifenote.db at ZIP root and app-private media under files/. */
object BackupManager {
    private const val DATABASE_NAME = "lifenote.db"
    private const val MANIFEST_NAME = "lifenote_backup.txt"
    private const val MAX_ENTRY_COUNT = 20_000
    private const val BUFFER_SIZE = 64 * 1024

    fun createBackup(context: Context, destination: Uri) {
        val db = AppDatabase.getInstance(context)
        // Ensure all committed Room/WAL changes are present in the main database file.
        db.openHelper.writableDatabase.query("PRAGMA wal_checkpoint(FULL)").use { cursor ->
            if (cursor.moveToFirst() && cursor.getInt(0) != 0) {
                error("ডেটাবেস প্রস্তুত করা যায়নি। কিছুক্ষণ পর আবার চেষ্টা করো।")
            }
        }

        val database = context.getDatabasePath(DATABASE_NAME)
        require(database.isFile && database.length() > 0L) { "ডেটাবেস পাওয়া যায়নি" }
        context.contentResolver.openOutputStream(destination, "w")?.use { raw ->
            ZipOutputStream(BufferedOutputStream(raw)).use { zip ->
                addFile(zip, database, DATABASE_NAME)
                addText(zip, MANIFEST_NAME, "LifeNote Backup\nformat=2\ndatabase=$DATABASE_NAME\n")
                addDirectory(zip, context.filesDir, context.filesDir, "files/")
            }
        } ?: error("ব্যাকআপ ফাইল তৈরি করা যায়নি")
    }

    fun restoreBackup(context: Context, source: Uri) {
        val tempRoot = File(context.cacheDir, "lifenote_restore_${System.currentTimeMillis()}")
        val tempDb = File(tempRoot, DATABASE_NAME)
        val tempFiles = File(tempRoot, "new_files")
        val oldFiles = File(tempRoot, "old_files")
        val oldDb = File(tempRoot, "old_$DATABASE_NAME")
        tempRoot.mkdirs()
        var databaseFound = false
        var filesStarted = false
        var dbReplaced = false
        try {
            val input = context.contentResolver.openInputStream(source)
                ?: error("ব্যাকআপ ফাইল খোলা যায়নি")
            ZipInputStream(BufferedInputStream(input)).use { zip ->
                var entryCount = 0
                while (true) {
                    val entry = zip.nextEntry ?: break
                    entryCount++
                    require(entryCount <= MAX_ENTRY_COUNT) { "ব্যাকআপে অতিরিক্ত ফাইল রয়েছে" }
                    val name = entry.name.replace('\\', '/')
                    require(!name.startsWith("/") && name.split('/').none { it == ".." }) {
                        "ব্যাকআপে অবৈধ ফাইল পাথ আছে"
                    }
                    when {
                        name == DATABASE_NAME || name.endsWith("/$DATABASE_NAME") -> {
                            tempDb.parentFile?.mkdirs()
                            FileOutputStream(tempDb).use { copyCurrentEntry(zip, it) }
                            databaseFound = true
                        }
                        name.startsWith("files/") && !entry.isDirectory -> {
                            val relative = name.removePrefix("files/")
                            require(relative.isNotBlank()) { "ব্যাকআপে অবৈধ ফাইল পাথ আছে" }
                            val out = File(tempFiles, relative)
                            require(out.canonicalPath.startsWith(tempFiles.canonicalPath + File.separator)) {
                                "ব্যাকআপে অবৈধ ফাইল পাথ আছে"
                            }
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { copyCurrentEntry(zip, it) }
                        }
                        // Older/alternate archives may store app files under filesDir/.
                        name.startsWith("filesDir/") && !entry.isDirectory -> {
                            val relative = name.removePrefix("filesDir/")
                            val out = File(tempFiles, relative)
                            require(out.canonicalPath.startsWith(tempFiles.canonicalPath + File.separator)) {
                                "ব্যাকআপে অবৈধ ফাইল পাথ আছে"
                            }
                            out.parentFile?.mkdirs()
                            FileOutputStream(out).use { copyCurrentEntry(zip, it) }
                        }
                        else -> drainCurrentEntry(zip)
                    }
                    zip.closeEntry()
                }
            }

            require(databaseFound && tempDb.length() > 100L) { "এটি বৈধ LifeNote ব্যাকআপ নয়: ডেটাবেস পাওয়া যায়নি" }
            validateDatabase(tempDb)

            // Close Room before replacing its database file.
            AppDatabase.closeForRestore()
            val dbFile = context.getDatabasePath(DATABASE_NAME)
            dbFile.parentFile?.mkdirs()
            val walFile = File(dbFile.path + "-wal")
            val shmFile = File(dbFile.path + "-shm")
            if (dbFile.exists()) {
                require(dbFile.renameTo(oldDb)) { "বর্তমান ডেটাবেস সাময়িকভাবে সরানো যায়নি" }
            }
            try {
                require(tempDb.copyTo(dbFile, overwrite = true).length() == tempDb.length()) {
                    "ডেটাবেস কপি সম্পূর্ণ হয়নি"
                }
                dbReplaced = true
                walFile.delete()
                shmFile.delete()

                if (context.filesDir.exists()) {
                    require(context.filesDir.renameTo(oldFiles)) { "পুরোনো মিডিয়া ফাইল সাময়িকভাবে সরানো যায়নি" }
                    filesStarted = true
                }
                require(context.filesDir.mkdirs() || context.filesDir.isDirectory) { "মিডিয়া ফোল্ডার তৈরি করা যায়নি" }
                if (tempFiles.exists()) copyDirectory(tempFiles, context.filesDir)
            } catch (e: Exception) {
                // Roll back both database and media if any part of restore fails.
                if (dbReplaced) dbFile.delete()
                if (oldDb.exists()) oldDb.renameTo(dbFile)
                if (filesStarted) {
                    context.filesDir.deleteRecursively()
                    oldFiles.renameTo(context.filesDir)
                }
                walFile.delete()
                shmFile.delete()
                throw e
            }
        } finally {
            tempRoot.deleteRecursively()
        }
    }

    private fun validateDatabase(file: File) {
        val sqlite = SQLiteDatabase.openDatabase(file.absolutePath, null, SQLiteDatabase.OPEN_READONLY)
        try {
            sqlite.rawQuery("PRAGMA integrity_check", null).use { cursor ->
                require(cursor.moveToFirst() && cursor.getString(0) == "ok") {
                    "ব্যাকআপের ডেটাবেস ক্ষতিগ্রস্ত"
                }
            }
            sqlite.rawQuery("PRAGMA user_version", null).use { cursor ->
                require(cursor.moveToFirst()) { "ডেটাবেস সংস্করণ পড়া যায়নি" }
                val version = cursor.getInt(0)
                require(version in 1..7) { "এই ব্যাকআপের ডেটাবেস সংস্করণ সমর্থিত নয়: $version" }
            }
        } finally {
            sqlite.close()
        }
    }

    private fun copyCurrentEntry(input: ZipInputStream, output: FileOutputStream) {
        val buffer = ByteArray(BUFFER_SIZE)
        while (true) {
            val count = input.read(buffer)
            if (count < 0) break
            output.write(buffer, 0, count)
        }
        output.fd.sync()
    }

    private fun drainCurrentEntry(input: ZipInputStream) {
        val buffer = ByteArray(BUFFER_SIZE)
        while (input.read(buffer) >= 0) { /* skip unsupported ZIP entry */ }
    }

    private fun addDirectory(zip: ZipOutputStream, current: File, root: File, prefix: String) {
        current.listFiles()?.forEach { file ->
            if (file.isDirectory) addDirectory(zip, file, root, prefix)
            else addFile(zip, file, prefix + file.relativeTo(root).invariantSeparatorsPath)
        }
    }

    private fun addFile(zip: ZipOutputStream, file: File, name: String) {
        zip.putNextEntry(ZipEntry(name))
        FileInputStream(file).use { it.copyTo(zip, BUFFER_SIZE) }
        zip.closeEntry()
    }

    private fun addText(zip: ZipOutputStream, name: String, value: String) {
        zip.putNextEntry(ZipEntry(name))
        zip.write(value.toByteArray(Charsets.UTF_8))
        zip.closeEntry()
    }

    private fun copyDirectory(source: File, destination: File) {
        source.listFiles()?.forEach { file ->
            val target = File(destination, file.name)
            if (file.isDirectory) {
                target.mkdirs()
                copyDirectory(file, target)
            } else {
                file.copyTo(target, overwrite = true)
            }
        }
    }
}
