package com.lifenote.app.backup

import android.content.Context
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun BackupRestoreScreen(context: Context) {
    val scope = rememberCoroutineScope()
    var message by remember { mutableStateOf("তোমার LifeNote-এর তথ্য নিরাপদে ZIP ফাইলে ব্যাকআপ রাখতে পারবে।") }
    var busy by remember { mutableStateOf(false) }
    var showRestoreWarning by remember { mutableStateOf(false) }

    val backupLauncher = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/zip")) { uri ->
        if (uri != null) {
            busy = true
            scope.launch {
                message = try {
                    withContext(Dispatchers.IO) { BackupManager.createBackup(context, uri) }
                    "ব্যাকআপ সফল হয়েছে। ZIP ফাইলটি নিরাপদ জায়গায় রেখে দাও।"
                } catch (e: Exception) { "ব্যাকআপ করা যায়নি: ${e.localizedMessage ?: "অজানা সমস্যা"}" }
                busy = false
            }
        }
    }
    val restoreLauncher = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri != null) {
            busy = true
            scope.launch {
                message = try {
                    withContext(Dispatchers.IO) { BackupManager.restoreBackup(context, uri) }
                    "রিস্টোর সম্পন্ন হয়েছে। পরিবর্তনগুলো দেখতে LifeNote বন্ধ করে আবার চালু করো।"
                } catch (e: Exception) { "রিস্টোর করা যায়নি: ${e.localizedMessage ?: "ফাইলটি পরীক্ষা করো"}" }
                busy = false
            }
        }
    }

    if (showRestoreWarning) {
        AlertDialog(
            onDismissRequest = { showRestoreWarning = false },
            title = { Text("পুরোনো ব্যাকআপ ফিরিয়ে আনবে?") },
            text = { Text("রিস্টোর করলে বর্তমান ডায়েরি, ছবি, ভয়েস নোট ও অন্যান্য অ্যাপের তথ্য ব্যাকআপের তথ্য দিয়ে প্রতিস্থাপিত হবে। আগে বর্তমান তথ্যের ব্যাকআপ নিয়ে নাও।") },
            confirmButton = { TextButton(onClick = { showRestoreWarning = false; restoreLauncher.launch(arrayOf("*/*")) }) { Text("ফাইল বেছে নাও") } },
            dismissButton = { TextButton(onClick = { showRestoreWarning = false }) { Text("বাতিল") } }
        )
    }

    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Backup & Restore", style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Backup তৈরি করো", style = MaterialTheme.typography.titleMedium)
                Text("ডায়েরি, মুড, স্মৃতি, To-Do, Reminder, Goals, Habits, Gratitude, Future Letter এবং অ্যাপের সংরক্ষিত ছবি ও ভয়েস নোট ZIP ফাইলে রাখা হবে।")
                Button(onClick = { backupLauncher.launch("LifeNote_Backup.zip") }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("ব্যাকআপ তৈরি করো") }
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Backup থেকে Restore", style = MaterialTheme.typography.titleMedium)
                Text("আগে তৈরি করা LifeNote ZIP ব্যাকআপ বেছে নিয়ে তথ্য ফিরিয়ে আনো। Google Drive বা ফোনের Files থেকে ZIP ফাইল বেছে নিতে পারবে।")
                OutlinedButton(onClick = { showRestoreWarning = true }, enabled = !busy, modifier = Modifier.fillMaxWidth()) { Text("ব্যাকআপ রিস্টোর করো") }
            }
        }
        if (busy) Text("কাজ চলছে…", color = MaterialTheme.colorScheme.primary)
        Text(message, style = MaterialTheme.typography.bodyMedium)
        Text("রিস্টোরের পর অ্যাপ সম্পূর্ণ বন্ধ করে আবার চালু করো। PIN সেটিংস ব্যাকআপে রাখা হয় না। রিস্টোরের আগে বর্তমান ডেটার আলাদা ব্যাকআপ রাখা ভালো।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}
