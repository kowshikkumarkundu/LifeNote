# LifeNote — Phase 5: To-Do & Reminders

Phase 5 adds a local task manager and reminder system on top of the working Phase 4 project.

## Included
- Task list with title, optional details, due date, priority (low/medium/high), and optional daily/weekly/monthly repeat
- Pending, completed, and all-task filters; completed history remains visible
- Overdue task indication and recurring task creation after completing a recurring task
- Local reminders with title, optional details, date, time, and one-time/daily/weekly/monthly repeat
- Enable/disable, delete, and 10-minute snooze controls for reminders
- Android notification channel and runtime notification permission on Android 13+
- Reminder alarms rescheduled after device reboot
- Offline Room storage; no account, backend, cloud sync, ads, or analytics
- Room migration 4 -> 5 creates only the new task and reminder tables; previous diary, calendar, mood, memory, image and audio data are retained
- Existing Phase 2 diary reader/editor, Phase 3 calendar/search, and Phase 4 mood/memories retained

## Notes
- Notifications require notification permission on Android 13 and newer.
- Android battery-management settings may delay inexact alarms on some devices.
- Reminders use Android's local AlarmManager; no internet connection is needed.

## Build on GitHub Actions
1. Remove the previous project ZIP from the repository root before uploading this one.
2. Upload this ZIP to the repository root.
3. Keep the existing repository workflow file unchanged.
4. Run the **Build LifeNote APK** workflow and download the APK artifact after a successful run.

Build requirements: JDK 17, Gradle 8.13, Android SDK 36.


## Phase 6 · Goals & Habits
- Personal goals with descriptions and progress updates (0–100%).
- Daily habit tracker with daily/weekday/weekly frequency labels and date-based completion records.
- Room database migration from version 5 to 6; existing diary, mood, memory, task and reminder data are retained.


## Phase 7 – Life insights and reflection
- Daily inspiration quote and diary statistics (entry and word counts).
- On This Day memories from previous years.
- Favorite diary marking and favorites overview.
- Gratitude journal with saved history.
- Future letters that remain hidden until their unlock date.
- Export diary text to PDF using Android document picker. PDF export includes text/title/date; image and audio attachments are not embedded.

## Phase 8 — Privacy & Security
- Optional 4–8 digit app PIN, stored as a salted PBKDF2-HMAC-SHA256 hash (the PIN itself is not stored).
- PIN prompt on app launch when PIN protection is enabled.
- Change/remove PIN and manually lock from Home → Privacy & Security.
- Existing Room database schema is unchanged in this phase; no database migration is required.
- Important limitation: this phase does not encrypt the Room database or media files, does not include biometric unlock, and does not yet implement a configurable background auto-lock timeout or screenshot blocking. Keep device-level screen lock enabled and maintain backups.

## Phase 8 — Privacy & Security
- Optional 4–8 digit app PIN, stored as a salted PBKDF2-HMAC-SHA256 hash (the PIN itself is not stored).
- PIN prompt on app launch when PIN protection is enabled.
- Change/remove PIN and manually lock from Home → Privacy & Security.
- Existing Room database schema is unchanged in this phase; no database migration is required.
- Important limitation: this phase does not encrypt the Room database or media files, does not include biometric unlock, and does not yet implement a configurable background auto-lock timeout or screenshot blocking. Keep device-level screen lock enabled and maintain backups.

## Phase 9 — Backup & Restore
- Create a ZIP backup containing the Room database and all app-private files (diary images, voice notes, and memory images).
- Restore from a previously created LifeNote ZIP backup using Android's file picker.
- Restore replaces the current database and app-private media files; the app should be fully closed and reopened after restore.
- PIN/security preferences are intentionally not included in the backup.
- Keep backup ZIP files in a safe location. A backup stored only on the same phone may be lost if the phone is damaged.

## Phase 9 Restore Reliability Fix
- Restore picker now accepts ZIP files from providers that label them with different MIME types (including Google Drive / Files providers).
- Restore validates the SQLite database integrity and supported schema version before replacing app data.
- Restore replaces the database and media files with rollback protection if copying fails.
- Existing Phase 9 ZIP backups (database at ZIP root and media under `files/`) remain supported.
- A small backup manifest is added to newly created backups.

## Phase 10 — Testing & Release Preparation
- Added a read-only app health screen accessible from the Home dashboard.
- Runs SQLite `PRAGMA integrity_check` and reports the number of records in each LifeNote feature table.
- Shows database/WAL/SHM and app-private media storage usage, plus the installed app version.
- Includes a practical pre-update backup and privacy checklist.
- No database schema changes or migrations; existing user data and Phase 9 backup format remain unchanged.
