package com.lifenote.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.Flag
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material.icons.outlined.AutoAwesome
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Surface
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.platform.LocalContext
import com.lifenote.app.backup.BackupRestoreScreen
import com.lifenote.app.security.SecurityStore
import com.lifenote.app.security.SecuritySettingsScreen
import com.lifenote.app.security.PinLockScreen
import androidx.compose.ui.Modifier
import androidx.compose.ui.Alignment
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.foundation.background
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.lifenote.app.R
import com.lifenote.app.ui.diary.DiaryScreen
import com.lifenote.app.ui.calendar.CalendarScreen
import com.lifenote.app.ui.phase4.Phase4Screen
import com.lifenote.app.ui.todo.ToDoScreen
import com.lifenote.app.ui.phase6.GoalsHabitsScreen
import com.lifenote.app.ui.phase7.Phase7Screen
import com.lifenote.app.ui.phase10.ReleaseCheckScreen
import androidx.navigation.NavType
import androidx.navigation.navArgument

private data class MainTab(
    val route: String,
    val label: Int,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LifeNoteApp() {
    val context = LocalContext.current
    var locked by remember { mutableStateOf(SecurityStore.hasPin(context)) }
    if (locked) { PinLockScreen(context) { locked = false }; return }
    val navController = rememberNavController()
    var diaryDetailOpen by remember { mutableStateOf(false) }
    val tabs = listOf(
        MainTab("home", R.string.nav_home, Icons.Outlined.Home),
        MainTab("diary", R.string.nav_diary, Icons.Outlined.MenuBook),
        MainTab("calendar", R.string.nav_calendar, Icons.Outlined.CalendarMonth),
        MainTab("todo", R.string.nav_todo, Icons.Outlined.Checklist),
        MainTab("growth", R.string.nav_growth, Icons.Outlined.Flag)
    )
    val backStackEntry = navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry.value?.destination

    Scaffold(
        containerColor = MaterialTheme.colorScheme.background,
        topBar = { if (currentDestination?.route == "home") TopAppBar(
            title = { Text(stringResource(R.string.app_name), fontWeight = FontWeight.Bold, color = Color(0xFF294437)) },
            colors = androidx.compose.material3.TopAppBarDefaults.topAppBarColors(containerColor = Color(0xFFF6F7F3))
        ) },
        bottomBar = {
            NavigationBar(containerColor = Color(0xFFFFFEFB), contentColor = Color(0xFF355B49)) {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true || (tab.route == "home" && currentDestination?.route == "phase4") || (tab.route == "diary" && currentDestination?.route?.startsWith("diaryEntry/") == true),
                        onClick = {
                            diaryDetailOpen = false
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = null) },
                        label = { Text(stringResource(tab.label)) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") { HomeDashboard(onOpenDiary = { navController.navigate("diary") }, onOpenCalendar = { navController.navigate("calendar") }, onOpenTodo = { navController.navigate("todo") }, onOpenPhase4 = { navController.navigate("phase4") }, onOpenGrowth = { navController.navigate("growth") }, onOpenMore = { navController.navigate("more") }, onOpenSecurity = { navController.navigate("security") }, onOpenBackup = { navController.navigate("backup") }, onOpenDiagnostics = { navController.navigate("diagnostics") }) }
            composable("phase4") { Phase4Screen() }
            composable("diary") { DiaryScreen(onReaderStateChanged = { diaryDetailOpen = it }) }
            composable("diaryEntry/{entryId}", arguments = listOf(navArgument("entryId") { type = NavType.LongType })) { backStack ->
                val entryId = backStack.arguments?.getLong("entryId")
                DiaryScreen(onReaderStateChanged = { diaryDetailOpen = it }, initialEntryId = entryId, onBackFromExternalEntry = { navController.popBackStack() })
            }
            composable("calendar") {
                CalendarScreen(onEntryClick = { id -> navController.navigate("diaryEntry/$id") })
            }
            composable("todo") { ToDoScreen() }
            composable("growth") { GoalsHabitsScreen() }
            composable("more") { Phase7Screen() }
            composable("security") { SecuritySettingsScreen(context) { locked = true } }
            composable("backup") { BackupRestoreScreen(context) }
            composable("diagnostics") { ReleaseCheckScreen(context) }
        }
    }
}

@Composable
private fun PlaceholderScreen(titleRes: Int, showFoundationCard: Boolean = false) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(text = stringResource(titleRes), style = MaterialTheme.typography.headlineSmall)
        }
        if (showFoundationCard) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.phase1_card_title), style = MaterialTheme.typography.titleMedium)
                        Text(stringResource(R.string.phase1_card_body), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            item {
                Text(stringResource(R.string.foundation_note), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun HomeDashboard(
    onOpenDiary: () -> Unit,
    onOpenCalendar: () -> Unit,
    onOpenTodo: () -> Unit,
    onOpenPhase4: () -> Unit,
    onOpenGrowth: () -> Unit = {},
    onOpenMore: () -> Unit = {},
    onOpenSecurity: () -> Unit = {},
    onOpenBackup: () -> Unit = {},
    onOpenDiagnostics: () -> Unit = {}
) {
    val ink = Color(0xFF20372F)
    val muted = Color(0xFF718078)
    val page = Color(0xFFF6F7F3)
    LazyColumn(
        modifier = Modifier.fillMaxSize().background(page).padding(horizontal = 18.dp),
        verticalArrangement = Arrangement.spacedBy(18.dp)
    ) {
        item {
            Column(modifier = Modifier.padding(top = 12.dp)) {
                Text("নিজের জন্য একটু সময়", style = MaterialTheme.typography.labelLarge, color = Color(0xFF728278))
                Text("আজকের দিনটা তোমার", style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold, color = ink)
                Text("লিখে রাখো, গুছিয়ে রাখো, মনে রাখো।", style = MaterialTheme.typography.bodyMedium, color = muted)
            }
        }
        item {
            Card(
                onClick = onOpenDiary,
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Transparent)
            ) {
                Box(
                    modifier = Modifier.fillMaxWidth()
                        .background(Brush.linearGradient(listOf(Color(0xFF28483C), Color(0xFF587565))))
                        .padding(22.dp)
                ) {
                    Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Text("✍️  TODAY'S JOURNAL", color = Color(0xFFDCE9DF), style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.SemiBold)
                        Text("মনের কথাগুলো\nলিখে রাখো", color = Color.White, style = MaterialTheme.typography.headlineMedium, fontWeight = FontWeight.Bold)
                        Text("একটি নতুন ডায়েরি এন্ট্রি শুরু করো", color = Color(0xFFE2EBE4), style = MaterialTheme.typography.bodyMedium)
                        Surface(color = Color(0xFFE7EFE8), shape = RoundedCornerShape(50)) {
                            Text("ডায়েরি লিখুন  →", modifier = Modifier.padding(horizontal = 16.dp, vertical = 9.dp), color = Color(0xFF28483C), fontWeight = FontWeight.SemiBold)
                        }
                    }
                    Text("✦", modifier = Modifier.align(Alignment.TopEnd), color = Color(0xFFB9CDBE), style = MaterialTheme.typography.displayMedium)
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text("দ্রুত প্রবেশ", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = ink)
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    HomeShortcut("ক্যালেন্ডার", "তারিখ ও স্মৃতি", "🗓️", Color(0xFFE8EFE8), Modifier.weight(1f), onOpenCalendar)
                    HomeShortcut("করণীয়", "To-do তালিকা", "☑️", Color(0xFFF3EDE2), Modifier.weight(1f), onOpenTodo)
                }
                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                    HomeShortcut("মুড ও স্মৃতি", "নিজের অনুভূতি", "🌿", Color(0xFFF1E9E7), Modifier.weight(1f), onOpenPhase4)
                    HomeShortcut("লক্ষ্য ও অভ্যাস", "নিজেকে এগিয়ে নাও", "🎯", Color(0xFFE9ECF5), Modifier.weight(1f), onOpenGrowth)
                }
            }
        }
        item {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                Text("নিজের জীবন গুছিয়ে রাখো", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.Bold, color = ink)
                HomeWideAction("✨", "জীবনের মুহূর্ত ও পরিসংখ্যান", "কৃতজ্ঞতা, প্রিয় ডায়েরি, ভবিষ্যতের চিঠি ও PDF Export", onOpenMore)
                HomeWideAction("🔒", "Privacy & Security", "PIN lock সেটিংস", onOpenSecurity)
                HomeWideAction("☁️", "Backup & Restore", "তোমার ব্যক্তিগত তথ্যের ব্যাকআপ রাখো", onOpenBackup)
                HomeWideAction("📊", "অ্যাপের অবস্থা", "ডেটাবেস, সংরক্ষিত তথ্য ও স্টোরেজ পরীক্ষা", onOpenDiagnostics)
            }
        }
        item {
            Box(modifier = Modifier.fillMaxWidth().padding(top = 2.dp, bottom = 20.dp), contentAlignment = Alignment.Center) {
                Text("L I F E N O T E   •   your personal space", color = Color(0xFF9AA69E), style = MaterialTheme.typography.labelSmall)
            }
        }
    }
}

@Composable
private fun HomeShortcut(
    title: String,
    subtitle: String,
    emoji: String,
    tint: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        onClick = onClick,
        modifier = modifier.height(132.dp),
        shape = RoundedCornerShape(22.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Column(modifier = Modifier.fillMaxSize().padding(15.dp), verticalArrangement = Arrangement.SpaceBetween) {
            Surface(color = tint, shape = RoundedCornerShape(13.dp)) {
                Text(emoji, modifier = Modifier.padding(9.dp), style = MaterialTheme.typography.titleMedium)
            }
            Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
                Text(title, color = Color(0xFF263B32), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Color(0xFF7A8980), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}

@Composable
private fun HomeWideAction(emoji: String, title: String, subtitle: String, onClick: () -> Unit) {
    Card(
        onClick = onClick,
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = Color.White),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp)
    ) {
        Row(modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(color = Color(0xFFF0F3EF), shape = RoundedCornerShape(13.dp)) {
                Text(emoji, modifier = Modifier.padding(10.dp), style = MaterialTheme.typography.titleMedium)
            }
            Column(modifier = Modifier.weight(1f).padding(start = 13.dp), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                Text(title, color = Color(0xFF263B32), style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.SemiBold)
                Text(subtitle, color = Color(0xFF7A8980), style = MaterialTheme.typography.bodySmall)
            }
            Text("›", color = Color(0xFF728278), style = MaterialTheme.typography.headlineSmall)
        }
    }
}
