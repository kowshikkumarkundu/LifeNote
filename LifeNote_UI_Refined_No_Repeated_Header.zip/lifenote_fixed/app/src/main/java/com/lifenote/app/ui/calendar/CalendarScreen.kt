package com.lifenote.app.ui.calendar

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.KeyboardArrowLeft
import androidx.compose.material.icons.outlined.KeyboardArrowRight
import androidx.compose.material.icons.outlined.Today
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lifenote.app.data.local.DiaryEntry
import com.lifenote.app.ui.diary.DiaryViewModel
import java.time.Instant
import java.time.LocalDate
import java.time.YearMonth
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

@Composable
fun CalendarScreen(onEntryClick: (Long) -> Unit, viewModel: DiaryViewModel = viewModel()) {
    val entries by viewModel.entries.collectAsState()
    val today = remember { LocalDate.now() }
    var visibleMonth by remember { mutableStateOf(YearMonth.from(today)) }
    var selectedDate by remember { mutableStateOf(today) }
    val entryDates = remember(entries) { entries.map { it.createdAt.toLocalDate() }.toSet() }
    val firstDayOffset = visibleMonth.atDay(1).dayOfWeek.value % 7
    val totalCells = ((firstDayOffset + visibleMonth.lengthOfMonth() + 6) / 7) * 7
    val selectedEntries = entries.filter { it.createdAt.toLocalDate() == selectedDate }

    LazyColumn(
        modifier = Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 16.dp),
        contentPadding = androidx.compose.foundation.layout.PaddingValues(top = 16.dp, bottom = 20.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Text("ডায়েরি ক্যালেন্ডার", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        }
        item {
            Card(shape = RoundedCornerShape(18.dp)) {
                Column(Modifier.fillMaxWidth().padding(12.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(onClick = { visibleMonth = visibleMonth.minusMonths(1) }) { Icon(Icons.Outlined.KeyboardArrowLeft, "আগের মাস") }
                        Text(visibleMonth.atDay(1).format(DateTimeFormatter.ofPattern("MMMM yyyy", Locale("bn", "BD"))), Modifier.weight(1f), style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                        IconButton(onClick = { visibleMonth = visibleMonth.plusMonths(1) }) { Icon(Icons.Outlined.KeyboardArrowRight, "পরের মাস") }
                        IconButton(onClick = { visibleMonth = YearMonth.from(today); selectedDate = today }) { Icon(Icons.Outlined.Today, "আজ") }
                    }
                    val weekdays = listOf("রবি", "সোম", "মঙ্গল", "বুধ", "বৃহঃ", "শুক্র", "শনি")
                    Row(Modifier.fillMaxWidth()) {
                        weekdays.forEach { day -> Box(Modifier.weight(1f), contentAlignment = Alignment.Center) { Text(day, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary) } }
                    }
                    for (week in 0 until totalCells / 7) {
                        Row(Modifier.fillMaxWidth()) {
                            for (dayIndex in 0 until 7) {
                                val dayNumber = week * 7 + dayIndex - firstDayOffset + 1
                                val date = if (dayNumber in 1..visibleMonth.lengthOfMonth()) visibleMonth.atDay(dayNumber) else null
                                val isSelected = date == selectedDate
                                val hasEntry = date != null && date in entryDates
                                Box(
                                    Modifier.weight(1f).height(46.dp).padding(2.dp).clip(CircleShape)
                                        .background(if (isSelected) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface)
                                        .clickable(enabled = date != null) { selectedDate = date!! },
                                    contentAlignment = Alignment.Center
                                ) {
                                    if (date != null) Column(horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.spacedBy(2.dp)) {
                                        Text(dayNumber.toString(), color = if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.bodyMedium, fontWeight = if (date == today || isSelected) FontWeight.Bold else FontWeight.Normal)
                                        if (hasEntry) Box(Modifier.size(5.dp).background(if (isSelected) MaterialTheme.colorScheme.onPrimary else MaterialTheme.colorScheme.primary, CircleShape))
                                        else Box(Modifier.size(5.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
        item {
            Text(selectedDate.format(DateTimeFormatter.ofPattern("dd MMMM yyyy", Locale("bn", "BD"))), style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        }
        if (selectedEntries.isEmpty()) {
            item {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Text("এই তারিখে কোনো ডায়েরি লেখা হয়নি।", Modifier.padding(16.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        } else {
            item {
                Text("${selectedEntries.size}টি ডায়েরি", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary)
            }
            items(selectedEntries, key = { it.id }) { entry ->
                DiaryCalendarEntry(entry) { onEntryClick(entry.id) }
            }
        }
    }
}

@Composable
private fun DiaryCalendarEntry(entry: DiaryEntry, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().clickable(onClick = onClick), shape = RoundedCornerShape(14.dp)) {
        Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(5.dp)) {
            Text(entry.title.ifBlank { "শিরোনামহীন ডায়েরি" }, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
            Text(entry.content.take(140), style = MaterialTheme.typography.bodyMedium, maxLines = 2)
            Text(Instant.ofEpochMilli(entry.createdAt).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("hh:mm a", Locale.getDefault())), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
        }
    }
}

private fun Long.toLocalDate(): LocalDate = Instant.ofEpochMilli(this).atZone(ZoneId.systemDefault()).toLocalDate()
