package com.lifenote.app.ui.todo

import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.os.Build
import android.content.pm.PackageManager
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Alarm
import androidx.compose.material.icons.outlined.CheckCircle
import androidx.compose.material.icons.outlined.DeleteOutline
import androidx.compose.material.icons.outlined.NotificationsActive
import androidx.compose.material.icons.outlined.Snooze
import androidx.compose.material.icons.outlined.TaskAlt
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import com.lifenote.app.data.local.AppDatabase
import com.lifenote.app.data.local.ReminderEntry
import com.lifenote.app.data.local.TaskEntry
import com.lifenote.app.reminders.ReminderScheduler
import kotlinx.coroutines.launch
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale

private val repeatOptions = listOf("NONE" to "একবার", "DAILY" to "প্রতিদিন", "WEEKLY" to "প্রতি সপ্তাহে", "MONTHLY" to "প্রতি মাসে")

@Composable
fun ToDoScreen() {
    val context = LocalContext.current
    val dao = remember { AppDatabase.getInstance(context).phase5Dao() }
    val scope = rememberCoroutineScope()
    val tasks by dao.observeTasks().collectAsState(initial = emptyList())
    val reminders by dao.observeReminders().collectAsState(initial = emptyList())
    var section by remember { mutableStateOf("tasks") }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) scope.launch { dao.getEnabledReminders().forEach { ReminderScheduler.schedule(context, it) } }
    }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(horizontal = 16.dp, vertical = 12.dp)) {
        Text("করণীয় ও রিমাইন্ডার", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
        Text("কাজ গুছিয়ে রাখো, প্রয়োজনীয় সময়ে মনে করিয়ে দেবে", color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(Modifier.height(12.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(section == "tasks", { section = "tasks" }, label = { Text("কাজের তালিকা") }, leadingIcon = { Icon(Icons.Outlined.TaskAlt, null) })
            FilterChip(section == "reminders", { section = "reminders" }, label = { Text("রিমাইন্ডার") }, leadingIcon = { Icon(Icons.Outlined.Alarm, null) })
        }
        HorizontalDivider(Modifier.padding(vertical = 8.dp))
        if (section == "tasks") TaskContent(tasks, Modifier.weight(1f),
            onAdd = { task -> scope.launch { dao.insertTask(task) } },
            onToggle = { task, done -> scope.launch {
                dao.updateTask(task.copy(isCompleted = done, completedAt = if (done) System.currentTimeMillis() else null))
                if (done && task.repeatType != "NONE") dao.insertTask(task.copy(id = 0, dueAt = nextDate(task.dueAt ?: System.currentTimeMillis(), task.repeatType), isCompleted = false, completedAt = null, createdAt = System.currentTimeMillis()))
            } }, onDelete = { id -> scope.launch { dao.deleteTask(id) } }
        ) else ReminderContent(reminders, Modifier.weight(1f),
            onAdd = { reminder -> scope.launch {
                val id = dao.insertReminder(reminder)
                val saved = reminder.copy(id = id)
                if (Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED) ReminderScheduler.schedule(context, saved)
            } },
            onUpdate = { reminder -> scope.launch { dao.updateReminder(reminder); if (reminder.isEnabled) ReminderScheduler.schedule(context, reminder) else ReminderScheduler.cancel(context, reminder) } },
            onDelete = { reminder -> scope.launch { ReminderScheduler.cancel(context, reminder); dao.deleteReminder(reminder.id) } },
            onRequestPermission = { if (Build.VERSION.SDK_INT >= 33) permissionLauncher.launch(android.Manifest.permission.POST_NOTIFICATIONS) }
        )
    }
}

@Composable
private fun TaskContent(tasks: List<TaskEntry>, modifier: Modifier, onAdd: (TaskEntry) -> Unit, onToggle: (TaskEntry, Boolean) -> Unit, onDelete: (Long) -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }
    var priority by remember { mutableStateOf("মাঝারি") }; var repeat by remember { mutableStateOf("NONE") }
    var dueAt by remember { mutableStateOf<Long?>(System.currentTimeMillis()) }; var filter by remember { mutableStateOf("all") }
    val visible = tasks.filter { when (filter) { "pending" -> !it.isCompleted; "done" -> it.isCompleted; else -> true } }
    LazyColumn(modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("নতুন কাজ যোগ করো", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(title, { title = it }, label = { Text("কাজের নাম") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(note, { note = it }, label = { Text("বিস্তারিত (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    Text("অগ্রাধিকার", style = MaterialTheme.typography.labelLarge)
                    Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { listOf("কম", "মাঝারি", "জরুরি").forEach { v -> FilterChip(priority == v, { priority = v }, label = { Text(v) }) } }
                    OutlinedButton(onClick = {
                        val c = Calendar.getInstance().apply { timeInMillis = dueAt ?: System.currentTimeMillis() }
                        DatePickerDialog(context, { _, y, m, d -> c.set(y, m, d, 23, 59, 0); dueAt = c.timeInMillis }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show()
                    }, modifier = Modifier.fillMaxWidth()) { Text("শেষ করার তারিখ: ${dueAt?.let { formatDate(it) } ?: "নির্ধারণ করা হয়নি"}") }
                    TextButton(onClick = { dueAt = null }) { Text("তারিখ সরিয়ে দাও") }
                    Text("পুনরাবৃত্তি", style = MaterialTheme.typography.labelLarge); RepeatPicker(repeat) { repeat = it }
                    Button(onClick = { if (title.isNotBlank()) { onAdd(TaskEntry(title = title.trim(), note = note.trim(), dueAt = dueAt, priority = priority, repeatType = repeat)); title = ""; note = ""; priority = "মাঝারি"; repeat = "NONE"; dueAt = System.currentTimeMillis() } }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Text("কাজ সেভ করো") }
                }
            }
        }
        item { Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) {
            FilterChip(filter == "all", { filter = "all" }, label = { Text("সব (${tasks.size})") })
            FilterChip(filter == "pending", { filter = "pending" }, label = { Text("বাকি (${tasks.count { !it.isCompleted }})") })
            FilterChip(filter == "done", { filter = "done" }, label = { Text("সম্পন্ন (${tasks.count { it.isCompleted }})") })
        } }
        if (visible.isEmpty()) item { EmptyCard(if (filter == "done") "এখনো কোনো কাজ সম্পন্ন হয়নি।" else "এখনো কোনো কাজ যোগ করা হয়নি।") }
        items(visible, key = { it.id }) { task ->
            val overdue = !task.isCompleted && task.dueAt != null && task.dueAt < System.currentTimeMillis()
            Card(Modifier.fillMaxWidth()) { Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                Checkbox(task.isCompleted, { onToggle(task, it) })
                Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(3.dp)) {
                    Text(task.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold, textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None)
                    if (task.note.isNotBlank()) Text(task.note, style = MaterialTheme.typography.bodySmall)
                    Text(buildString { append("অগ্রাধিকার: ${task.priority}"); task.dueAt?.let { append(" · ${formatDate(it)}") }; if (task.repeatType != "NONE") append(" · ${repeatLabel(task.repeatType)}") }, style = MaterialTheme.typography.bodySmall, color = if (overdue) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onSurfaceVariant)
                    if (overdue) Text("সময় পেরিয়ে গেছে", color = MaterialTheme.colorScheme.error, style = MaterialTheme.typography.labelSmall)
                    if (task.isCompleted && task.completedAt != null) Text("সম্পন্ন: ${formatDate(task.completedAt)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                IconButton(onClick = { onDelete(task.id) }) { Icon(Icons.Outlined.DeleteOutline, contentDescription = "মুছে ফেলো") }
            } }
        }
    }
}

@Composable
private fun ReminderContent(reminders: List<ReminderEntry>, modifier: Modifier, onAdd: (ReminderEntry) -> Unit, onUpdate: (ReminderEntry) -> Unit, onDelete: (ReminderEntry) -> Unit, onRequestPermission: () -> Unit) {
    val context = LocalContext.current
    var title by remember { mutableStateOf("") }; var note by remember { mutableStateOf("") }
    var triggerAt by remember { mutableStateOf(System.currentTimeMillis() + 3600000L) }; var repeat by remember { mutableStateOf("NONE") }
    val hasPermission = Build.VERSION.SDK_INT < 33 || ContextCompat.checkSelfPermission(context, android.Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED
    LazyColumn(modifier.fillMaxSize(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        if (!hasPermission) item { Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.secondaryContainer)) { Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) { Text("নোটিফিকেশন অনুমতি প্রয়োজন", fontWeight = FontWeight.SemiBold); Text("সময় হলে রিমাইন্ডার দেখানোর জন্য নোটিফিকেশনের অনুমতি প্রয়োজন।"); Button(onClick = onRequestPermission) { Text("অনুমতি দাও") } } } }
        item {
            Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant), shape = RoundedCornerShape(20.dp)) {
                Column(Modifier.fillMaxWidth().padding(15.dp), verticalArrangement = Arrangement.spacedBy(9.dp)) {
                    Text("নতুন রিমাইন্ডার", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
                    OutlinedTextField(title, { title = it }, label = { Text("কী মনে করিয়ে দেবে?") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                    OutlinedTextField(note, { note = it }, label = { Text("বিস্তারিত (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth(), minLines = 2)
                    OutlinedButton(onClick = { val c = Calendar.getInstance().apply { timeInMillis = triggerAt }; DatePickerDialog(context, { _, y, m, d -> c.set(y, m, d); triggerAt = c.timeInMillis }, c.get(Calendar.YEAR), c.get(Calendar.MONTH), c.get(Calendar.DAY_OF_MONTH)).show() }, modifier = Modifier.fillMaxWidth()) { Text("তারিখ: ${formatDate(triggerAt)}") }
                    OutlinedButton(onClick = { val c = Calendar.getInstance().apply { timeInMillis = triggerAt }; TimePickerDialog(context, { _, h, min -> c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, min); c.set(Calendar.SECOND, 0); triggerAt = c.timeInMillis }, c.get(Calendar.HOUR_OF_DAY), c.get(Calendar.MINUTE), false).show() }, modifier = Modifier.fillMaxWidth()) { Text("সময়: ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(triggerAt))}") }
                    Text("পুনরাবৃত্তি", style = MaterialTheme.typography.labelLarge); RepeatPicker(repeat) { repeat = it }
                    Button(onClick = { if (title.isNotBlank()) { onAdd(ReminderEntry(title = title.trim(), note = note.trim(), triggerAt = triggerAt, repeatType = repeat)); title = ""; note = ""; triggerAt = System.currentTimeMillis() + 3600000L; repeat = "NONE" } }, enabled = title.isNotBlank(), modifier = Modifier.fillMaxWidth()) { Icon(Icons.Outlined.NotificationsActive, null); Spacer(Modifier.width(6.dp)); Text("রিমাইন্ডার সেভ করো") }
                }
            }
        }
        item { Text("সংরক্ষিত রিমাইন্ডার (${reminders.size})", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold) }
        if (reminders.isEmpty()) item { EmptyCard("এখনো কোনো রিমাইন্ডার তৈরি করা হয়নি।") }
        items(reminders, key = { it.id }) { r -> Card(Modifier.fillMaxWidth()) { Column(Modifier.fillMaxWidth().padding(13.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) { Column(Modifier.weight(1f)) { Text(r.title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold); Text("${formatDate(r.triggerAt)} · ${SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(r.triggerAt))}", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant); Text(repeatLabel(r.repeatType), style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }; Switch(r.isEnabled, { onUpdate(r.copy(isEnabled = it)) }) }
            if (r.note.isNotBlank()) Text(r.note)
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) { OutlinedButton(onClick = { onUpdate(r.copy(triggerAt = System.currentTimeMillis() + 600000L, isEnabled = true)) }, enabled = r.isEnabled) { Icon(Icons.Outlined.Snooze, null); Spacer(Modifier.width(4.dp)); Text("১০ মিনিট পরে") }; TextButton(onClick = { onDelete(r) }) { Icon(Icons.Outlined.DeleteOutline, null); Text("মুছে ফেলো") } }
        } } }
    }
}

@Composable
private fun RepeatPicker(selected: String, onSelect: (String) -> Unit) {
    Column(verticalArrangement = Arrangement.spacedBy(2.dp)) {
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { repeatOptions.take(2).forEach { (v, label) -> FilterChip(selected == v, { onSelect(v) }, label = { Text(label) }) } }
        Row(horizontalArrangement = Arrangement.spacedBy(5.dp)) { repeatOptions.drop(2).forEach { (v, label) -> FilterChip(selected == v, { onSelect(v) }, label = { Text(label) }) } }
    }
}
@Composable
private fun EmptyCard(message: String) { Card(Modifier.fillMaxWidth()) { Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) { Icon(Icons.Outlined.CheckCircle, null, tint = MaterialTheme.colorScheme.onSurfaceVariant); Spacer(Modifier.width(9.dp)); Text(message, color = MaterialTheme.colorScheme.onSurfaceVariant) } } }
private fun repeatLabel(value: String) = repeatOptions.firstOrNull { it.first == value }?.second ?: "একবার"
private fun formatDate(time: Long) = SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(time))
private fun nextDate(time: Long, repeat: String): Long { val c = Calendar.getInstance().apply { timeInMillis = time }; when (repeat) { "DAILY" -> c.add(Calendar.DAY_OF_YEAR, 1); "WEEKLY" -> c.add(Calendar.WEEK_OF_YEAR, 1); "MONTHLY" -> c.add(Calendar.MONTH, 1) }; return c.timeInMillis }
