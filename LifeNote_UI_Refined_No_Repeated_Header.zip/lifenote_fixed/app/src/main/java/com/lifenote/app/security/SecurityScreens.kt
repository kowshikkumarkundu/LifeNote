package com.lifenote.app.security

import android.content.Context
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp

@Composable
fun SecuritySettingsScreen(context: Context, onLockNow: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirm by remember { mutableStateOf("") }
    var message by remember { mutableStateOf("") }
    var hasPin by remember { mutableStateOf(SecurityStore.hasPin(context)) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(20.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Text("Privacy & Security", style = MaterialTheme.typography.headlineSmall)
        Text(if (hasPin) "একটি PIN চালু আছে।" else "অ্যাপের জন্য ৪–৮ সংখ্যার PIN সেট করো।")
        OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(8) }, label = { Text("নতুন PIN") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
        OutlinedTextField(confirm, { confirm = it.filter(Char::isDigit).take(8) }, label = { Text("PIN নিশ্চিত করো") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true)
        Button(onClick = {
            if (pin.length in 4..8 && pin == confirm) { SecurityStore.setPin(context, pin); hasPin = true; pin = ""; confirm = ""; message = "PIN সংরক্ষিত হয়েছে। পরেরবার অ্যাপ খুললে PIN চাইবে।" }
            else message = "PIN ৪–৮ সংখ্যার হতে হবে এবং দুটো PIN মিলতে হবে।"
        }, modifier = Modifier.fillMaxWidth()) { Text(if (hasPin) "PIN পরিবর্তন" else "PIN চালু করো") }
        if (hasPin) {
            OutlinedButton(onClick = { SecurityStore.removePin(context); hasPin = false; message = "PIN বন্ধ করা হয়েছে।" }, modifier = Modifier.fillMaxWidth()) { Text("PIN বন্ধ করো") }
            OutlinedButton(onClick = onLockNow, modifier = Modifier.fillMaxWidth()) { Text("এখনই অ্যাপ Lock করো") }
        }
        if (message.isNotBlank()) Text(message, color = MaterialTheme.colorScheme.primary)
        Text("PIN হারিয়ে গেলে অ্যাপের ডেটা মুছে না ফেলে PIN পুনরুদ্ধারের কোনো ব্যবস্থা নেই। তাই PIN নিরাপদে মনে রাখবে।", style = MaterialTheme.typography.bodySmall)
        Text("এই সংস্করণে PIN সুরক্ষা আছে; Room ডেটাবেস বা সংযুক্ত মিডিয়া ফাইল আলাদাভাবে এনক্রিপ্ট করা হয়নি।", style = MaterialTheme.typography.bodySmall)
    }
}

@Composable
fun PinLockScreen(context: Context, onUnlocked: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var error by remember { mutableStateOf(false) }
    Column(Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).padding(28.dp), verticalArrangement = Arrangement.Center) {
        Text("LifeNote Locked", style = MaterialTheme.typography.headlineMedium)
        Text("তোমার PIN দিয়ে Unlock করো।", modifier = Modifier.padding(top = 8.dp, bottom = 20.dp))
        OutlinedTextField(pin, { pin = it.filter(Char::isDigit).take(8); error = false }, label = { Text("PIN") }, visualTransformation = PasswordVisualTransformation(), keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword), singleLine = true, modifier = Modifier.fillMaxWidth())
        if (error) Text("PIN সঠিক নয়। আবার চেষ্টা করো।", color = MaterialTheme.colorScheme.error)
        Button(onClick = { if (SecurityStore.verify(context, pin)) onUnlocked() else { error = true; pin = "" } }, modifier = Modifier.fillMaxWidth().padding(top = 14.dp)) { Text("Unlock") }
    }
}
