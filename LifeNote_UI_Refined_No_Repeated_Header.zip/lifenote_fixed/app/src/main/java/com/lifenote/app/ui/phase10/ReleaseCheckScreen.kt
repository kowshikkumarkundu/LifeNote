package com.lifenote.app.ui.phase10

import android.content.Context
import android.content.pm.PackageInfo
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CircularProgressIndicator
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.lifenote.app.data.local.AppDatabase
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

private data class HealthReport(
    val databaseOk: Boolean,
    val counts: Map<String, Long>,
    val databaseBytes: Long,
    val mediaBytes: Long,
    val version: String,
    val checkedAt: String
)

@Composable
fun ReleaseCheckScreen(context: Context) {
    val scope = rememberCoroutineScope()
    var report by remember { mutableStateOf<HealthReport?>(null) }
    var running by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf<String?>(null) }

    fun runCheck() {
        if (running) return
        running = true
        error = null
        scope.launch {
            try {
                report = withContext(Dispatchers.IO) { collectReport(context) }
            } catch (e: Exception) {
                error = e.localizedMessage ?: "পরীক্ষা সম্পন্ন করা যায়নি।"
            } finally {
                running = false
            }
        }
    }

    Column(
        Modifier.fillMaxSize().background(MaterialTheme.colorScheme.background).verticalScroll(rememberScrollState()).padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text("অ্যাপ পরীক্ষা ও তথ্য", style = MaterialTheme.typography.headlineSmall)
        Text("LifeNote-এর ডেটাবেস, সংরক্ষিত তথ্য এবং স্টোরেজ সম্পর্কে একটি read-only পরীক্ষা চালাও। এই পরীক্ষা তোমার কোনো তথ্য পরিবর্তন করবে না।")

        Button(onClick = { runCheck() }, enabled = !running, modifier = Modifier.fillMaxWidth()) {
            if (running) {
                CircularProgressIndicator()
                Text(" পরীক্ষা চলছে…")
            } else Text("এখন পরীক্ষা করো")
        }
        error?.let { Text("পরীক্ষা করা যায়নি: $it", color = MaterialTheme.colorScheme.error) }

        report?.let { data ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ডেটাবেসের অবস্থা", style = MaterialTheme.typography.titleMedium)
                    Text(if (data.databaseOk) "✓ ডেটাবেস ঠিক আছে" else "⚠ ডেটাবেস পরীক্ষা সফল হয়নি", color = if (data.databaseOk) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    Text("সর্বশেষ পরীক্ষা: ${data.checkedAt}", style = MaterialTheme.typography.bodySmall)
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("সংরক্ষিত তথ্যের হিসাব", style = MaterialTheme.typography.titleMedium)
                    data.counts.forEach { (label, count) ->
                        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            Text(label)
                            Text(count.toString(), style = MaterialTheme.typography.titleSmall)
                        }
                    }
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(7.dp)) {
                    Text("স্টোরেজ ব্যবহার", style = MaterialTheme.typography.titleMedium)
                    InfoRow("ডেটাবেস", formatBytes(data.databaseBytes))
                    InfoRow("ছবি, অডিও ও অন্যান্য মিডিয়া", formatBytes(data.mediaBytes))
                    InfoRow("মোট", formatBytes(data.databaseBytes + data.mediaBytes))
                }
            }
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text("অ্যাপের সংস্করণ", style = MaterialTheme.typography.titleMedium)
                    Text("LifeNote ${data.version}")
                    Text("ব্যক্তিগত ও অফলাইন ব্যবহারের জন্য তৈরি। কোনো অ্যাকাউন্ট বা ক্লাউড সিঙ্ক নেই।", style = MaterialTheme.typography.bodySmall)
                }
            }
        } ?: Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("পরীক্ষা এখনো চালানো হয়নি", style = MaterialTheme.typography.titleMedium)
                Text("উপরের বোতামে চাপ দিলে ডেটাবেসের integrity এবং সংরক্ষিত তথ্যের সংখ্যা দেখা যাবে।")
            }
        }

        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("রিলিজের আগে মনে রাখবে", style = MaterialTheme.typography.titleMedium)
                Text("• অ্যাপ আপডেটের আগে একটি নতুন Backup তৈরি করো।")
                Text("• Backup ZIP অন্য নিরাপদ জায়গাতেও রাখো।")
                Text("• Restore পরীক্ষা করার সময় প্রয়োজনীয় পুরোনো Backup অক্ষত রাখো।")
                Text("• PIN ভুলে গেলে বর্তমান সংস্করণে PIN recovery নেই।")
                Text("• PIN চালু থাকলেও ডেটাবেস ও মিডিয়া আলাদাভাবে এনক্রিপ্ট করা হয় না।")
            }
        }
        OutlinedButton(onClick = { report = null; error = null }, modifier = Modifier.fillMaxWidth()) {
            Text("ফলাফল মুছে ফেলো")
        }
    }
}

@Composable
private fun InfoRow(label: String, value: String) {
    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
        Text(label)
        Text(value, style = MaterialTheme.typography.titleSmall)
    }
}

private fun collectReport(context: Context): HealthReport {
    val db = AppDatabase.getInstance(context)
    val sql = db.openHelper.readableDatabase
    val integrity = sql.query("PRAGMA integrity_check").use { cursor ->
        cursor.moveToFirst() && cursor.getString(0).equals("ok", ignoreCase = true)
    }
    val tables = linkedMapOf(
        "ডায়েরি" to "diary_entries",
        "মুড" to "mood_entries",
        "বিশেষ স্মৃতি" to "memory_entries",
        "To-Do" to "tasks",
        "Reminder" to "reminders",
        "লক্ষ্য" to "goals",
        "অভ্যাস" to "habits",
        "অভ্যাসের রেকর্ড" to "habit_logs",
        "কৃতজ্ঞতার নোট" to "gratitude_entries",
        "ভবিষ্যতের চিঠি" to "future_letters"
    )
    val counts = linkedMapOf<String, Long>()
    tables.forEach { (label, table) ->
        val count = try {
            sql.query("SELECT COUNT(*) FROM `$table`").use { cursor ->
                if (cursor.moveToFirst()) cursor.getLong(0) else 0L
            }
        } catch (_: Exception) { 0L }
        counts[label] = count
    }
    val databaseFile = context.getDatabasePath("lifenote.db")
    val databaseBytes = databaseFile.length() + File(databaseFile.path + "-wal").length() + File(databaseFile.path + "-shm").length()
    val mediaBytes = directorySize(context.filesDir)
    val packageInfo: PackageInfo = context.packageManager.getPackageInfo(context.packageName, 0)
    @Suppress("DEPRECATION")
    val version = "${packageInfo.versionName ?: "unknown"} (${packageInfo.versionCode})"
    val time = java.text.SimpleDateFormat("dd MMM yyyy, hh:mm a", java.util.Locale.getDefault()).format(java.util.Date())
    return HealthReport(integrity, counts, databaseBytes, mediaBytes, version, time)
}

private fun directorySize(file: File): Long {
    if (!file.exists()) return 0L
    if (file.isFile) return file.length()
    return file.listFiles()?.sumOf { directorySize(it) } ?: 0L
}

private fun formatBytes(bytes: Long): String {
    if (bytes < 1024L) return "$bytes B"
    val kb = bytes / 1024.0
    if (kb < 1024.0) return String.format(java.util.Locale.getDefault(), "%.1f KB", kb)
    return String.format(java.util.Locale.getDefault(), "%.2f MB", kb / 1024.0)
}
