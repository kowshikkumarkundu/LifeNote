package com.lifenote.app.ui.theme

import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Shapes
import androidx.compose.material3.Typography
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp

private val LifeNoteLightColors = lightColorScheme(
    primary = Color(0xFF355B49),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDCE9DF),
    onPrimaryContainer = Color(0xFF20392D),
    secondary = Color(0xFF8A7561),
    onSecondary = Color.White,
    secondaryContainer = Color(0xFFF0E8DC),
    onSecondaryContainer = Color(0xFF4B3D30),
    tertiary = Color(0xFF667B73),
    onTertiary = Color.White,
    background = Color(0xFFF6F7F3),
    onBackground = Color(0xFF24372F),
    surface = Color(0xFFFFFEFB),
    onSurface = Color(0xFF263B32),
    surfaceVariant = Color(0xFFE9EFE9),
    onSurfaceVariant = Color(0xFF68786F),
    outline = Color(0xFFD5DED6),
    outlineVariant = Color(0xFFE7ECE7),
    error = Color(0xFFB54742),
    errorContainer = Color(0xFFF9E5E2)
)

private val LifeNoteShapes = Shapes(
    extraSmall = RoundedCornerShape(10.dp),
    small = RoundedCornerShape(14.dp),
    medium = RoundedCornerShape(20.dp),
    large = RoundedCornerShape(26.dp),
    extraLarge = RoundedCornerShape(30.dp)
)

@Composable
fun LifeNoteTheme(content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = LifeNoteLightColors,
        shapes = LifeNoteShapes,
        typography = Typography(),
        content = content
    )
}
