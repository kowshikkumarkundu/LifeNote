package com.lifenote.app.ui.diary

import android.Manifest
import android.content.pm.PackageManager
import android.media.MediaRecorder
import android.media.MediaPlayer
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.Add
import androidx.compose.material.icons.outlined.Delete
import androidx.compose.material.icons.outlined.Image
import androidx.compose.material.icons.outlined.Mic
import androidx.compose.material.icons.outlined.Stop
import androidx.compose.material3.AlertDialog
import androidx.compose.foundation.Image
import androidx.compose.foundation.layout.size
import androidx.compose.ui.layout.ContentScale
import coil.compose.AsyncImage
import androidx.compose.material3.Button
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import androidx.lifecycle.viewmodel.compose.viewModel
import com.lifenote.app.data.local.DiaryEntry
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DiaryScreen(viewModel: DiaryViewModel = viewModel()) {
    val context = LocalContext.current
    val entries by viewModel.entries.collectAsState()
    var editing by remember { mutableStateOf(false) }
    var entryId by remember { mutableStateOf(0L) }
    var createdAt by remember { mutableStateOf(System.currentTimeMillis()) }
    var title by remember { mutableStateOf("") }
    var content by remember { mutableStateOf("") }
    var imagePath by remember { mutableStateOf<String?>(null) }
    var audioPath by remember { mutableStateOf<String?>(null) }
    var showDelete by remember { mutableStateOf<DiaryEntry?>(null) }
    var previewImage by remember { mutableStateOf<String?>(null) }
    var recording by remember { mutableStateOf(false) }
    var recorder by remember { mutableStateOf<MediaRecorder?>(null) }
    var pendingAudioFile by remember { mutableStateOf<File?>(null) }

    fun startNew() {
        entryId = 0L; createdAt = System.currentTimeMillis(); title = ""; content = ""
        imagePath = null; audioPath = null; editing = true
    }
    fun openEntry(entry: DiaryEntry) {
        entryId = entry.id; createdAt = entry.createdAt; title = entry.title; content = entry.content
        imagePath = entry.imagePath; audioPath = entry.voiceNotePath; editing = true
    }
    fun saveNow() {
        if (title.isBlank() && content.isBlank()) return
        viewModel.save(DiaryEntry(entryId, createdAt, System.currentTimeMillis(), title, content, imagePath, audioPath)) {
            entryId = it
        }
    }

    val imagePicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            val file = File(context.filesDir, "diary_image_${System.currentTimeMillis()}.jpg")
            context.contentResolver.openInputStream(it)?.use { input -> file.outputStream().use { output -> input.copyTo(output) } }
            imagePath = file.absolutePath
        }
    }
    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { granted ->
        if (granted) {
            val file = File(context.filesDir, "voice_${System.currentTimeMillis()}.m4a")
            try {
                val r = MediaRecorder()
                r.setAudioSource(MediaRecorder.AudioSource.MIC)
                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4)
                r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                r.setOutputFile(file.absolutePath)
                r.prepare(); r.start(); recorder = r; pendingAudioFile = file; recording = true
            } catch (_: Exception) { recorder?.release(); recorder = null; recording = false }
        }
    }

    LaunchedEffect(editing, entryId, title, content, imagePath, audioPath) {
        if (editing && (title.isNotBlank() || content.isNotBlank())) {
            delay(800)
            saveNow()
        }
    }
    DisposableEffect(Unit) {
        onDispose {
            try { if (recording) recorder?.stop() } catch (_: Exception) { }
            try { recorder?.release() } catch (_: Exception) { }
        }
    }

    if (previewImage != null) {
        Dialog(onDismissRequest = { previewImage = null }) {
            AsyncImage(model = File(previewImage!!), contentDescription = "Diary image", modifier = Modifier.fillMaxWidth(), contentScale = ContentScale.Fit)
        }
    }

    if (showDelete != null) {
        AlertDialog(
            onDismissRequest = { showDelete = null },
            title = { Text("ডায়েরি মুছে ফেলবে?") },
            text = { Text("এই এন্ট্রিটি মুছে ফেলা হবে।") },
            confirmButton = { TextButton(onClick = { showDelete?.let(viewModel::delete); showDelete = null }) { Text("মুছে ফেলো") } },
            dismissButton = { TextButton(onClick = { showDelete = null }) { Text("বাতিল") } }
        )
    }

    if (editing) {
        LazyColumn(
            modifier = Modifier.fillMaxSize().padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            item { Text(if (entryId == 0L) "নতুন ডায়েরি" else "ডায়েরি সম্পাদনা", style = MaterialTheme.typography.headlineSmall) }
            item { Text("${formatDate(createdAt)} · ${formatTime(createdAt)}", style = MaterialTheme.typography.bodySmall) }
            item {
                OutlinedTextField(value = title, onValueChange = { title = it }, label = { Text("শিরোনাম (ঐচ্ছিক)") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
            }
            item {
                OutlinedTextField(value = content, onValueChange = { content = it }, label = { Text("আজকের কথা লিখো…") }, modifier = Modifier.fillMaxWidth(), minLines = 10)
            }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { imagePicker.launch("image/*") }) { Icon(Icons.Outlined.Image, null); Text("ছবি") }
                    Button(onClick = {
                        if (recording) {
                            try { recorder?.stop(); recorder?.release(); audioPath = pendingAudioFile?.absolutePath }
                            catch (_: Exception) { pendingAudioFile?.delete() }
                            recorder = null; recording = false
                        } else if (ContextCompat.checkSelfPermission(context, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED) {
                            val file = File(context.filesDir, "voice_${System.currentTimeMillis()}.m4a")
                            try {
                                val r = MediaRecorder(); r.setAudioSource(MediaRecorder.AudioSource.MIC)
                                r.setOutputFormat(MediaRecorder.OutputFormat.MPEG_4); r.setAudioEncoder(MediaRecorder.AudioEncoder.AAC)
                                r.setOutputFile(file.absolutePath); r.prepare(); r.start()
                                recorder = r; pendingAudioFile = file; recording = true
                            } catch (_: Exception) { rSafeRelease(recorder); recorder = null }
                        } else permissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                    }) {
                        Icon(if (recording) Icons.Outlined.Stop else Icons.Outlined.Mic, null)
                        Text(if (recording) "রেকর্ডিং বন্ধ" else "ভয়েস নোট")
                    }
                }
            }
            if (imagePath != null) item {
                AsyncImage(model = File(imagePath!!), contentDescription = "সংযুক্ত ছবি", modifier = Modifier.fillMaxWidth().clickable { previewImage = imagePath }.size(180.dp), contentScale = ContentScale.Crop)
            }
            if (audioPath != null) item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("ভয়েস নোট সংরক্ষিত", color = MaterialTheme.colorScheme.primary)
                    TextButton(onClick = {
                        try { audioPath?.let { path -> MediaPlayer().apply { setDataSource(path); setOnCompletionListener { player -> player.release() }; prepare(); start() } } } catch (_: Exception) { }
                    }) { Text("শুনুন") }
                }
            }
            if (recording) item { Text("রেকর্ডিং চলছে… বন্ধ করলে সংরক্ষিত হবে।", color = MaterialTheme.colorScheme.error) }
            item { Text("লেখা স্বয়ংক্রিয়ভাবে সংরক্ষিত হচ্ছে", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.secondary) }
            item {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { if (recording) { try { recorder?.stop() } catch (_: Exception) {}; recorder?.release(); audioPath = pendingAudioFile?.absolutePath; recorder = null; recording = false }; saveNow(); editing = false }) { Text("সম্পন্ন") }
                    TextButton(onClick = { if (recording) { try { recorder?.stop() } catch (_: Exception) {}; recorder?.release(); recorder = null; recording = false }; editing = false }) { Text("বন্ধ") }
                }
            }
        }
    } else {
        Column(modifier = Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Column { Text("আমার ডায়েরি", style = MaterialTheme.typography.headlineSmall); Text("${entries.size}টি এন্ট্রি", style = MaterialTheme.typography.bodySmall) }
                Button(onClick = ::startNew) { Icon(Icons.Outlined.Add, null); Text("নতুন লেখা") }
            }
            if (entries.isEmpty()) {
                Card(colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)) {
                    Text("এখনো কোনো ডায়েরি লেখা হয়নি। আজকের দিনটি দিয়ে শুরু করো।", modifier = Modifier.padding(18.dp))
                }
            } else {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    items(entries, key = { it.id }) { entry ->
                        Card(modifier = Modifier.fillMaxWidth().clickable { openEntry(entry) }, shape = RoundedCornerShape(14.dp)) {
                            Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Row(horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                    Text(entry.title.ifBlank { "শিরোনামহীন ডায়েরি" }, style = MaterialTheme.typography.titleMedium, modifier = Modifier.weight(1f))
                                    IconButton(onClick = { showDelete = entry }) { Icon(Icons.Outlined.Delete, contentDescription = "Delete") }
                                }
                                Text("${formatDate(entry.createdAt)} · ${formatTime(entry.createdAt)}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.secondary)
                                Text(entry.content, maxLines = 3, style = MaterialTheme.typography.bodyMedium)
                                if (entry.imagePath != null) AsyncImage(model = File(entry.imagePath), contentDescription = "ডায়েরির ছবি", modifier = Modifier.fillMaxWidth().size(150.dp).clickable { previewImage = entry.imagePath }, contentScale = ContentScale.Crop)
                                if (entry.voiceNotePath != null) Text("🎙 ভয়েস নোট সংযুক্ত", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                                if (entry.imagePath != null || entry.voiceNotePath != null) Text("সংযুক্তি আছে", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.primary)
                            }
                        }
                    }
                }
            }
        }
    }
}

private fun formatDate(time: Long): String = SimpleDateFormat("dd MMM yyyy", Locale.getDefault()).format(Date(time))
private fun formatTime(time: Long): String = SimpleDateFormat("hh:mm a", Locale.getDefault()).format(Date(time))
private fun rSafeRelease(recorder: MediaRecorder?) { try { recorder?.release() } catch (_: Exception) { } }
