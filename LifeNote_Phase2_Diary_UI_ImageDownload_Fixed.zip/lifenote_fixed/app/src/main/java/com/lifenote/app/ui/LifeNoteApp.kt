package com.lifenote.app.ui

import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.CalendarMonth
import androidx.compose.material.icons.outlined.Checklist
import androidx.compose.material.icons.outlined.Home
import androidx.compose.material.icons.outlined.MenuBook
import androidx.compose.material3.Card
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.navigation.NavDestination.Companion.hierarchy
import androidx.navigation.NavGraph.Companion.findStartDestination
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.currentBackStackEntryAsState
import androidx.navigation.compose.rememberNavController
import com.lifenote.app.R
import com.lifenote.app.ui.diary.DiaryScreen

private data class MainTab(
    val route: String,
    val label: Int,
    val icon: androidx.compose.ui.graphics.vector.ImageVector
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun LifeNoteApp() {
    val navController = rememberNavController()
    var diaryDetailOpen by remember { mutableStateOf(false) }
    val tabs = listOf(
        MainTab("home", R.string.nav_home, Icons.Outlined.Home),
        MainTab("diary", R.string.nav_diary, Icons.Outlined.MenuBook),
        MainTab("calendar", R.string.nav_calendar, Icons.Outlined.CalendarMonth),
        MainTab("todo", R.string.nav_todo, Icons.Outlined.Checklist)
    )
    val backStackEntry = navController.currentBackStackEntryAsState()
    val currentDestination = backStackEntry.value?.destination

    Scaffold(
        topBar = { if (!diaryDetailOpen) TopAppBar(title = { Text(stringResource(R.string.app_name)) }) },
        bottomBar = {
            NavigationBar {
                tabs.forEach { tab ->
                    NavigationBarItem(
                        selected = currentDestination?.hierarchy?.any { it.route == tab.route } == true,
                        onClick = {
                            diaryDetailOpen = false
                            navController.navigate(tab.route) {
                                popUpTo(navController.graph.findStartDestination().id) { saveState = true }
                                launchSingleTop = true
                                restoreState = true
                            }
                        },
                        icon = { Icon(tab.icon, contentDescription = null) },
                        label = { Text(stringResource(tab.label)) }
                    )
                }
            }
        }
    ) { innerPadding ->
        NavHost(
            navController = navController,
            startDestination = "home",
            modifier = Modifier.padding(innerPadding)
        ) {
            composable("home") { PlaceholderScreen(R.string.welcome_title, true) }
            composable("diary") { DiaryScreen(onReaderStateChanged = { diaryDetailOpen = it }) }
            composable("calendar") { PlaceholderScreen(R.string.calendar_coming) }
            composable("todo") { PlaceholderScreen(R.string.todo_coming) }
        }
    }
}

@Composable
private fun PlaceholderScreen(titleRes: Int, showFoundationCard: Boolean = false) {
    LazyColumn(
        modifier = Modifier.fillMaxSize().padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(text = stringResource(titleRes), style = MaterialTheme.typography.headlineSmall)
        }
        if (showFoundationCard) {
            item {
                Card(modifier = Modifier.fillMaxWidth()) {
                    Column(modifier = Modifier.padding(18.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(stringResource(R.string.phase1_card_title), style = MaterialTheme.typography.titleMedium)
                        Text(stringResource(R.string.phase1_card_body), style = MaterialTheme.typography.bodyMedium)
                    }
                }
            }
            item {
                Text(stringResource(R.string.foundation_note), style = MaterialTheme.typography.bodySmall)
            }
        }
    }
}
