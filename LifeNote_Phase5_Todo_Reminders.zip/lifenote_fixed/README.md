# LifeNote — Phase 5: To-Do & Reminders

Phase 5 adds a local task manager and reminder system on top of the working Phase 4 project.

## Included
- Task list with title, optional details, due date, priority (low/medium/high), and optional daily/weekly/monthly repeat
- Pending, completed, and all-task filters; completed history remains visible
- Overdue task indication and recurring task creation after completing a recurring task
- Local reminders with title, optional details, date, time, and one-time/daily/weekly/monthly repeat
- Enable/disable, delete, and 10-minute snooze controls for reminders
- Android notification channel and runtime notification permission on Android 13+
- Reminder alarms rescheduled after device reboot
- Offline Room storage; no account, backend, cloud sync, ads, or analytics
- Room migration 4 -> 5 creates only the new task and reminder tables; previous diary, calendar, mood, memory, image and audio data are retained
- Existing Phase 2 diary reader/editor, Phase 3 calendar/search, and Phase 4 mood/memories retained

## Notes
- Notifications require notification permission on Android 13 and newer.
- Android battery-management settings may delay inexact alarms on some devices.
- Reminders use Android's local AlarmManager; no internet connection is needed.

## Build on GitHub Actions
1. Remove the previous project ZIP from the repository root before uploading this one.
2. Upload this ZIP to the repository root.
3. Keep the existing repository workflow file unchanged.
4. Run the **Build LifeNote APK** workflow and download the APK artifact after a successful run.

Build requirements: JDK 17, Gradle 8.13, Android SDK 36.
