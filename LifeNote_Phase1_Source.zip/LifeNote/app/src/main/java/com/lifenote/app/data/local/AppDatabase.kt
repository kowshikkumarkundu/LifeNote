package com.lifenote.app.data.local

import androidx.room.Database
import androidx.room.RoomDatabase

/** Feature-specific entities and safe migrations are added in later phases. */
@Database(entities = [AppMetadataEntity::class], version = 1, exportSchema = true)
abstract class AppDatabase : RoomDatabase() {
    abstract fun appMetadataDao(): AppMetadataDao
}
