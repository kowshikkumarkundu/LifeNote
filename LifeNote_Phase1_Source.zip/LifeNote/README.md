# LifeNote – Phase 1 Foundation

Personal, offline-first Android life journal. Built with Kotlin, Jetpack Compose, Material 3, MVVM-ready structure, Room and DataStore.

## Requirements
- JDK 17
- Android SDK Platform 36
- Gradle 8.13

## Build locally
```bash
gradle :app:assembleDebug
```
APK output: `app/build/outputs/apk/debug/app-debug.apk` (debug application ID includes `.debug`).

## Build with GitHub Actions
1. Create a GitHub repository and upload the contents of this ZIP to its root (do not upload the ZIP as a nested file).
2. Push to the `main` branch, or open Actions → Build LifeNote APK → Run workflow.
3. Download the `LifeNote-debug-apk` artifact from the completed workflow run.

## Phase 1 contents
- Android project and build configuration
- Compose + Material 3 light theme
- English and Bangla string resources (follows device locale for now)
- Initial Home / Diary / Calendar / To-Do navigation shell
- Room database foundation
- DataStore preferences foundation
- GitHub Actions debug APK workflow

Feature screens and data entities are intentionally added in their planned phases. This foundation build does not yet contain the complete diary, reminder, backup or security features.
